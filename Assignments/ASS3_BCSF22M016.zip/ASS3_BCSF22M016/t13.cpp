// Calculate height of binary tree – Iterative
// Similar approach as that of Level Order Traversal - count levels
#include <iostream>
#include <queue>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

int heightIteratively(TreeNode *node)
{
    int height = 0;

    if (node == NULL)
        return height;

    queue<TreeNode *> q;
    q.push(node);

    while (!q.empty())
    {
        ++height;
        int size = q.size();

        while (size > 0)
        {
            --size;
            TreeNode *curr = q.front();
            q.pop();

            if (curr->left != NULL)
                q.push(curr->left);

            if (curr->right != NULL)
                q.push(curr->right);
        }
    }

    return height;
}

int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->left->right->left = new TreeNode(7);
    root->right->right = new TreeNode(6);
    root->right->right->left = new TreeNode(8);
    root->right->right->left->left = new TreeNode(9);

    int height = heightIteratively(root);
    cout << "Height of tree: " << height << endl;
}