#include <iostream>
#include <climits>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

bool isValidBST(TreeNode *root, long long minVal, long long maxVal)
{
    if (root == nullptr)
        return true;

    if (root->val >= maxVal || root->val <= minVal)
        return false;

    return isValidBST(root->left, minVal, root->val) && isValidBST(root->right, root->val, maxVal);
}

bool isValidBST(TreeNode *root)
{
    return isValidBST(root, LONG_MIN, LONG_MAX);
}

int main()
{
    // NOT A BST

    // TreeNode *root = new TreeNode(1);
    // root->left = new TreeNode(2);
    // root->right = new TreeNode(3);
    // root->left->left = new TreeNode(4);
    // root->left->right = new TreeNode(5);
    // root->left->right->left = new TreeNode(7);
    // root->right->right = new TreeNode(6);
    // root->right->right->left = new TreeNode(8);
    // root->right->right->left->left = new TreeNode(9);

    // BST

    TreeNode *root = new TreeNode(5);
    root->left = new TreeNode(3);
    root->right = new TreeNode(8);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(4);
    root->right->left = new TreeNode(6);
    root->right->right = new TreeNode(9);

    if (isValidBST(root))
        cout << "--- The given Binary tree is a BST! ---" << endl;
    else
        cout << "--- The given Binary tree is not a BST! ---" << endl;
}