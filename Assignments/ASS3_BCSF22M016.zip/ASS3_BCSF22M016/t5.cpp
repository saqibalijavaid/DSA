#include <iostream>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

int solve(TreeNode *root, int &valid)
{
    if (!root)
        return 0;

    if (!root->left && !root->right) // LEAF NODE
        return root->val;

    if (valid == 0)
        return 0;

    int leftSum = solve(root->left, valid);
    int rightSum = solve(root->right, valid);

    if (leftSum + rightSum != root->val)
        valid = 0;

    return leftSum + rightSum + root->val;
}

bool isSumTree(TreeNode *root)
{
    int valid = 1;
    solve(root, valid);
    return valid;
}

int main(void)
{
    // SUM TREE
    
    TreeNode *root = new TreeNode(16);
    root->left = new TreeNode(3);
    root->right = new TreeNode(5);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(1);
    root->right->left = new TreeNode(4);
    root->right->right = new TreeNode(1);

    if (isSumTree(root))
        cout << "--- The given Binary tree is a Sum Tree! ---" << endl;
    else
        cout << "--- The given Binary tree is not a Sum Tree! ---" << endl;
}