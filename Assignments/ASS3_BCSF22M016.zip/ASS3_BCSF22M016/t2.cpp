#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

void inorderTraversal(TreeNode *root, vector<int> &elements)
{
    if (!root)
        return;

    inorderTraversal(root->left, elements);
    elements.insert(elements.end(), root->val);
    inorderTraversal(root->right, elements);
}

bool areIdenticalSets(TreeNode *root1, TreeNode *root2)
{
    vector<int> elements1, elements2;

    inorderTraversal(root1, elements1);
    inorderTraversal(root2, elements2);

    sort(elements1.begin(), elements1.end());
    sort(elements2.begin(), elements2.end());

    if (elements1.size() != elements2.size())
        return false;

    for (size_t i = 0; i < elements1.size(); ++i)
    {
        if (elements1[i] != elements2[i])
            return false;
    }

    return true;
}

int main()
{
    TreeNode *root1 = new TreeNode(2);
    root1->left = new TreeNode(1);
    root1->right = new TreeNode(3);

    TreeNode *root2 = new TreeNode(2);
    root2->left = new TreeNode(1);
    root2->right = new TreeNode(3);

    if (areIdenticalSets(root1, root2))
    {
        cout << "The trees contain unique sets of elements." << endl;
    }
    else
    {
        cout << "No unique sets of elements." << endl;
    }

    return 0;
}