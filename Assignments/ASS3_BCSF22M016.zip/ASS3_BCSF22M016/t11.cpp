#include <iostream>
#include <queue> // for BFS
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

bool isCompleteTree(TreeNode *root)
{
    // Using BFS

    queue<TreeNode *> q;
    q.push(root);

    bool past = false;

    while (!q.empty())
    {
        TreeNode *temp = q.front();
        q.pop();

        if (temp == NULL)
            past = true;
        else
        {
            if (past == true)
            {
                return false;
            }

            q.push(temp->left);
            q.push(temp->right);
        }
    }

    return true;
}

int main(void)
{
    // Complete TREE

    TreeNode *root = new TreeNode(16);
    root->left = new TreeNode(3);
    root->right = new TreeNode(5);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(1);
    root->right->left = new TreeNode(4);
    root->right->right = new TreeNode(1);

    if (isCompleteTree(root))
        cout << "--- The given Binary tree is a Complete Tree! ---" << endl;
    else
        cout << "--- The given Binary tree is not a Complete Tree! ---" << endl;
}