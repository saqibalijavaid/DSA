#include <iostream>
#include <queue> // for Reverse Level Order Traversal (BFS)
#include <vector>
#include <algorithm> // for reverse func
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x)  : val(x), left(NULL), right(NULL) {}
};

void reverseLevelOrderTraversal(TreeNode *root)
{
    vector<int> ans;

    if (!root)
        return;

    queue<TreeNode *> q;
    q.push(root);

    while (!q.empty())
    {
        TreeNode *temp = q.front();
        ans.push_back(temp->val);
        q.pop();

        if (temp->right)
            q.push(temp->right);

        if (temp->left)
            q.push(temp->left);
    }

    reverse(ans.begin(), ans.end());

    for (int i = 0; i < ans.size(); i++)
    {
        cout << ans[i] << " ";
    }
    cout << endl;
}

int main(void)
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->right->left = new TreeNode(6);
    root->right->right = new TreeNode(7);

    cout << "Printing the Reverse Level Order Traversal:" << endl;
    reverseLevelOrderTraversal(root);
}