#include <iostream>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;
    bool deleted;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL), deleted(false) {}
};

void markAsDeleted(TreeNode *root, int val)
{
    if (!root)
        return;
    if (val < root->val)
        markAsDeleted(root->left, val);
    else if (val > root->val)
        markAsDeleted(root->right, val);
    else
        root->deleted = true;
}

TreeNode *findMin(TreeNode *root)
{
    while (root && root->left)
        root = root->left;
    return root;
}

TreeNode *cleanup(TreeNode *root)
{
    if (!root)
        return nullptr;

    root->left = cleanup(root->left);
    root->right = cleanup(root->right);

    if (root->deleted)
    {
        // Node to be deleted
        if (!root->left)
        {
            TreeNode *temp = root->right;
            delete root;
            return temp;
        }
        if (!root->right)
        {
            TreeNode *temp = root->left;
            delete root;
            return temp;
        }

        // Node with two children: Get the inorder successor (smallest in the right subtree)
        TreeNode *temp = findMin(root->right);

        // Copy the inorder successor's content to this node
        root->val = temp->val;
        root->deleted = temp->deleted;

        root->right = cleanup(root->right);
    }

    return root;
}

void inorderTraversal(TreeNode *root)
{
    if (!root)
        return;
    inorderTraversal(root->left);
    if (!root->deleted)
        cout << root->val << " ";
    inorderTraversal(root->right);
}

int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->left->right->left = new TreeNode(7);
    root->right->right = new TreeNode(6);
    root->right->right->left = new TreeNode(8);
    root->right->right->left->left = new TreeNode(9);

    // Mark some nodes as deleted
    markAsDeleted(root, 20);

    cout << "In-order traversal of the BST (before cleanup): ";
    inorderTraversal(root);
    cout << endl;

    // Cleanup to remove deleted nodes
    root = cleanup(root);

    cout << "In-order traversal of the BST (after cleanup): ";
    inorderTraversal(root);
    cout << endl;

    return 0;
}