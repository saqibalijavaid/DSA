#include <iostream>
#include <vector>
#include <cmath>
#include <limits>

using namespace std;

int findBestPlayer(const vector<int> &players, vector<int> &lostTo)
{
    int n = players.size();
    vector<int> tournament = players;

    // Vector to keep track of which player lost to which player
    lostTo.resize(n, -1);

    // Tournament rounds
    while (tournament.size() > 1)
    {

        vector<int> nextRound;

        for (size_t i = 0; i < tournament.size(); i += 2)
        {
            int winner, loser;
            if (tournament[i] > tournament[i + 1])
            {
                winner = tournament[i];
                loser = tournament[i + 1];
            }
            else
            {
                winner = tournament[i + 1];
                loser = tournament[i];
            }

            nextRound.push_back(winner);
            lostTo[loser] = winner;
        }

        tournament = nextRound;
    }

    return tournament[0];
}

int findSecondBestPlayer(const vector<int> &players, int bestPlayer, const vector<int> &lostTo)
{
    int secondBest = -1;

    // Find players who lost to the best player
    vector<int> candidates;
    for (size_t i = 0; i < players.size(); ++i)
    {
        if (lostTo[players[i]] == bestPlayer)
        {
            candidates.push_back(players[i]);
        }
    }

    if (candidates.empty())
        return -1;

    secondBest = candidates[0];
    for (size_t i = 1; i < candidates.size(); ++i)
    {
        if (candidates[i] > secondBest)
        {
            secondBest = candidates[i];
        }
    }

    return secondBest;
}

int main()
{
    vector<int> players = {1, 2, 7, 3, 4, 5, 6, 8};
    vector<int> lostTo;

    int bestPlayer = findBestPlayer(players, lostTo);
    int secondBestPlayer = findSecondBestPlayer(players, bestPlayer, lostTo);

    cout << "The best player is: " << bestPlayer << endl;
    cout << "The second best player is: " << secondBestPlayer << endl;

    return 0;
}