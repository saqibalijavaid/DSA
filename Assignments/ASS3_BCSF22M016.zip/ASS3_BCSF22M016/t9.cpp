#include <iostream>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

TreeNode *removeNodesInRange(TreeNode *root, int min, int max)
{
    if (root == NULL)
        return NULL;

    root->left = removeNodesInRange(root->left, min, max);
    root->right = removeNodesInRange(root->right, min, max);

    if (root->val >= min && root->val <= max)
    {
        TreeNode *temp;
        if (root->left == NULL)
        {
            temp = root->right;
            delete root;
            return temp;
        }
        else if (root->right == NULL)
        {
            temp = root->left;
            delete root;
            return temp;
        }
        else
        {
            temp = root->right;
            while (temp && temp->left != NULL)
                temp = temp->left;
            root->val = temp->val;
            root->right = removeNodesInRange(root->right, temp->val, temp->val);
        }
    }

    return root;
}

void inorder(TreeNode *root)
{
    if (root == NULL)
        return;
    inorder(root->left);
    cout << root->val << " ";
    inorder(root->right);
}

int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->left->right->left = new TreeNode(7);
    root->right->right = new TreeNode(6);
    root->right->right->left = new TreeNode(8);
    root->right->right->left->left = new TreeNode(9);

    int min = 5, max = 8;

    inorder(root);
    cout << endl;
    root = removeNodesInRange(root, min, max);

    cout << "Inorder traversal after removing nodes in range [" << min << ", " << max << "] : ";
    inorder(root);
    cout << endl;
}