#include <iostream>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

TreeNode *removeNodesOutsideRange(TreeNode *root, int min, int max)
{
    if (root == NULL)
        return NULL;

    root->left = removeNodesOutsideRange(root->left, min, max);
    root->right = removeNodesOutsideRange(root->right, min, max);

    if (root->val < min)
    {
        TreeNode *rightChild = root->right;
        delete root;
        return rightChild;
    }

    if (root->val > max)
    {
        TreeNode *leftChild = root->left;
        delete root;
        return leftChild;
    }

    return root;
}

void inorder(TreeNode *root)
{
    if (root == NULL)
        return;
    inorder(root->left);
    cout << root->val << " ";
    inorder(root->right);
}

int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->left->right->left = new TreeNode(7);
    root->right->right = new TreeNode(6);
    root->right->right->left = new TreeNode(8);
    root->right->right->left->left = new TreeNode(9);

    int min = 5, max = 8;
    inorder(root);
    cout << endl;
    root = removeNodesOutsideRange(root, min, max);

    cout << "Inorder traversal after removing nodes outside range [" << min << ", " << max << "] : ";
    inorder(root);
    cout << endl;
}