#include <iostream>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

int kthSmallest(TreeNode *root, int &k)
{
    if (!root)
        return -1;
    int left = kthSmallest(root->left, k);
    if (k == 0)
        return left;
    k--;
    if (k == 0)
        return root->val;
    return kthSmallest(root->right, k);
}

int kthLargest(TreeNode *root, int &k)
{
    if (!root)
        return -1;
    int right = kthLargest(root->right, k);
    if (k == 0)
        return right;
    k--;
    if (k == 0)
        return root->val;
    return kthLargest(root->left, k);
}

void printInOrder(TreeNode *root)
{
    if (!root)
        return;
    printInOrder(root->left);
    cout << root->val << " ";
    printInOrder(root->right);
}

int main()
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    root->left->right->left = new TreeNode(7);
    root->right->right = new TreeNode(6);
    root->right->right->left = new TreeNode(8);
    root->right->right->left->left = new TreeNode(9);

    // Print the BST in in-order traversal
    cout << "BST in in-order traversal: ";
    printInOrder(root);
    cout << endl;

    // Find and print the k-th smallest element
    int k = 3;
    int result = kthSmallest(root, k);
    if (result != -1)
    {
        cout << "The smallest element is " << result << endl;
    }
    else
    {
        cout << "The tree does not have enough elements." << endl;
    }

    // Find and print the k-th largest element
    k = 3;
    result = kthLargest(root, k);
    if (result != -1)
    {
        cout << "The largest element is " << result << endl;
    }
    else
    {
        cout << "The tree does not have enough elements." << endl;
    }

    return 0;
}