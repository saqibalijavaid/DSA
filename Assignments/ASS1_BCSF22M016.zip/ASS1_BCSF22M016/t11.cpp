#include <iostream>
#include <string>
#include <stdexcept>

using namespace std;

class Node
{
public:
    float data;
    Node *next;

    // constructor
    Node(float data) : data(data), next(nullptr) {}
};

class Stack
{
    Node *top;

public:
    Stack() : top(nullptr) {}

    void push(float data)
    {
        Node *temp = new Node(data);
        temp->next = top;
        top = temp;
    }

    void pull()
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack Underflow");
        }
        Node *temp = top;
        top = top->next;
        delete temp;
    }

    float peek() const
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack is empty!");
        }
        return top->data;
    }

    bool isEmpty() const
    {
        return top == nullptr;
    }

    int size() const
    {
        Node *temp = top;
        int count = 0;
        while (temp != nullptr)
        {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

class VariableNode
{
public:
    string variableName;
    float value;
    VariableNode *next;

    VariableNode(const string &name, float val) : variableName(name), value(val), next(nullptr) {}
};

int precedent(char c)
{
    if (c == '*' || c == '/')
    {
        return 2;
    }
    else if (c == '+' || c == '-')
    {
        return 1;
    }
    return -1;
}

string infixToPostfix(const string &expression)
{
    Stack st;
    string postfix = "";

    for (int i = 0; i < expression.length(); ++i)
    {
        char ch = expression[i];

        // Operand
        if (isalnum(ch))
        {
            while (i < expression.length() && (isalnum(expression[i]) || expression[i] == '_'))
            {
                postfix += expression[i];
                ++i;
            }
            postfix += ' ';
            --i;
        }
        // Opening parenthesis
        else if (ch == '(')
        {
            st.push(ch);
        }
        // Closing parenthesis
        else if (ch == ')')
        {
            while (!st.isEmpty() && st.peek() != '(')
            {
                postfix += st.peek();
                postfix += ' ';
                st.pull();
            }
            if (!st.isEmpty() && st.peek() == '(')
            {
                st.pull();
            }
        }
        // Operator
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/')
        {
            while (!st.isEmpty() && precedent(ch) <= precedent(st.peek()))
            {
                postfix += st.peek();
                postfix += ' ';
                st.pull();
            }
            st.push(ch);
        }
    }

    while (!st.isEmpty())
    {
        postfix += st.peek();
        postfix += ' ';
        st.pull();
    }

    return postfix;
}

VariableNode *extractVariables(const string &expression)
{
    VariableNode *head = nullptr;
    VariableNode *tail = nullptr;

    for (int i = 0; i < expression.length(); ++i)
    {
        if (isalpha(expression[i]))
        {
            string varName = "";

            while (i < expression.length() && (isalnum(expression[i]) || expression[i] == '_'))
            {
                varName += expression[i];
                ++i;
            }
            --i;

            // Checking if that variable already exist (i.e. one variable can come multiple times in expression)
            VariableNode *temp = head;
            bool exists = false;
            while (temp != nullptr)
            {
                if (temp->variableName == varName)
                {
                    exists = true;
                    break;
                }
                temp = temp->next;
            }

            // if the variable does not already exist
            if (!exists)
            {
                int varValue;
                cout << "Enter value for " << varName << ": ";
                cin >> varValue;

                VariableNode *newNode = new VariableNode(varName, varValue);

                if (head == nullptr)
                {
                    head = newNode;
                    tail = newNode;
                }
                else
                {
                    tail->next = newNode;
                    tail = newNode;
                }
            }
        }
    }

    return head;
}

int getVariableValue(const string &varName, VariableNode *variableList)
{
    VariableNode *temp = variableList; // variableList -> head node 
    while (temp != nullptr)
    {
        if (temp->variableName == varName)
        {
            return temp->value;
        }
        temp = temp->next;
    }

    throw runtime_error("Undefined variable: " + varName);
}

float evaluatePostfix(const string &postfixExpression, VariableNode *variableList)
{
    Stack s;

    for (int i = 0; i < postfixExpression.length(); ++i)
    {
        char ch = postfixExpression[i];

        // Space
        if (isspace(ch))
        {
            continue;
        }

        // Digit (Operand)
        if (isdigit(ch))
        {
            int num = 0;
            while (i < postfixExpression.length() && isdigit(postfixExpression[i]))
            {
                num = num * 10 + (postfixExpression[i] - '0');
                ++i;
            }
            --i;
            s.push(num);
        }

        // Alphabet (Operand)
        else if (isalpha(ch))
        {
            string varName = "";
            while (i < postfixExpression.length() && (isalnum(postfixExpression[i]) || postfixExpression[i] == '_'))
            {
                varName += postfixExpression[i];
                ++i;
            }
            --i;
            int varValue = getVariableValue(varName, variableList); // variableList -> head node
            s.push(varValue);
        }

        // Operator
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/')
        {
            float operand2 = s.peek();
            s.pull();
            float operand1 = s.peek();
            s.pull();
            float result;

            switch (ch)
            {
            case '+':
                result = operand1 + operand2;
                break;
            case '-':
                result = operand1 - operand2;
                break;
            case '*':
                result = operand1 * operand2;
                break;
            case '/':
                if (operand2 == 0)
                {
                    throw runtime_error("Division by zero error");
                }
                result = operand1 / operand2;
                break;
            default:
                throw runtime_error("Unknown operator encountered");
            }
            s.push(result);
        }

        // Any Other Character
        else
        {
            throw runtime_error("Invalid character encountered in the expression");
        }
    }

    if (s.size() != 1)
    {
        throw runtime_error("Invalid postfix expression");
    }

    return s.peek();
}

int main()
{
    // string infixExpression = "(temperatureFahrenheit- 32) * 5/9";
    string infixExpression = "a";
    // string infixExpression = "((obtainedMarks + bonus) / totalMarks) * 100";

    string postfixExpression = infixToPostfix(infixExpression);
    cout << "Postfix Expression: " << postfixExpression << endl;

    VariableNode *variables = extractVariables(infixExpression);

    float result = evaluatePostfix(postfixExpression, variables);
    cout << "Evaluation Result: " << result << endl;

    // Clean up variables list
    VariableNode *current = variables;
    while (current != nullptr)
    {
        VariableNode *next = current->next;
        delete current;
        current = next;
    }

    return 0;
}