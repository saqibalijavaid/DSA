#include <iostream>
#include <vector>
#include <set>

using namespace std;

class TicTacToe
{
    char board[3][3];
    vector<pair<int, int>> georgeMoves;
    vector<pair<int, int>> yourMoves;
    set<pair<int, int>> occupiedMoves; // Track all moves

public:
    TicTacToe()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                board[i][j] = '.';
            }
        }
    }

    bool isWinner(char player)
    {
        // Check rows and columns
        for (int i = 0; i < 3; i++)
        {
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player)
                return true;
            if (board[0][i] == player && board[1][i] == player && board[2][i] == player)
                return true;
        }
        // Check diagonals
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player)
            return true;
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player)
            return true;

        return false;
    }

    bool canWin(char player)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (board[i][j] == '.')
                {
                    board[i][j] = player;
                    bool win = isWinner(player);
                    board[i][j] = '.'; // revert the move
                    if (win)
                        return true;
                }
            }
        }
        return false;
    }

    void playGame(vector<pair<int, int>> &preferenceList)
    {
        for (const auto &move : preferenceList)
        {
            int r = move.first - 1;
            int c = move.second - 1;

            // Ensure George's move is valid and not overwritten
            if (board[r][c] == '.')
            {
                board[r][c] = 'G';
                georgeMoves.push_back({r + 1, c + 1});
                occupiedMoves.insert({r, c});
            }

            // Check if George won
            if (isWinner('G'))
            {
                break;
            }

            // Check if you can win in the next move
            bool moveMade = false;
            for (int i = 0; i < 3 && !moveMade; i++)
            {
                for (int j = 0; j < 3 && !moveMade; j++)
                {
                    if (board[i][j] == '.' && occupiedMoves.find({i, j}) == occupiedMoves.end())
                    {
                        // Temporarily place your move
                        board[i][j] = 'Y';
                        // Check if this move wins the game for you
                        if (isWinner('Y'))
                        {
                            yourMoves.push_back({i + 1, j + 1});
                            occupiedMoves.insert({i, j});
                            moveMade = true;
                        }
                        else
                        {
                            board[i][j] = '.'; // Revert move
                        }
                    }
                }
            }

            // If you cannot win, block George
            if (!moveMade)
            {
                for (int i = 0; i < 3 && !moveMade; i++)
                {
                    for (int j = 0; j < 3 && !moveMade; j++)
                    {
                        if (board[i][j] == '.' && occupiedMoves.find({i, j}) == occupiedMoves.end())
                        {
                            // Temporarily place your move
                            board[i][j] = 'Y';
                            // Check if this move blocks George's win
                            if (!canWin('G'))
                            {
                                yourMoves.push_back({i + 1, j + 1});
                                occupiedMoves.insert({i, j});
                                moveMade = true;
                            }
                            board[i][j] = '.'; // Revert move
                        }
                    }
                }
            }
        }
    }

    void printYourMoves()
    {
        for (const auto &move : yourMoves)
        {
            cout << move.first << " " << move.second << endl;
        }
    }

    void printBoard()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                cout << board[i][j] << " ";
            }
            cout << endl;
        }
    }
};

int main()
{
    TicTacToe game;

    // Input George's preference list
    vector<pair<int, int>> preferenceList;
    cout << "Enter George's moves (row and column) for 9 moves (or fewer if you want to stop early):" << endl;
    for (int i = 0; i < 9; ++i)
    {
        int r, c;
        cout << "Move " << i + 1 << ": ";
        cin >> r >> c;
        if (r < 1 || r > 3 || c < 1 || c > 3)
        {
            cout << "Invalid move, try again." << endl;
            --i;
        }
        else
        {
            preferenceList.push_back({r, c});
        }
    }

    // Play the game
    game.playGame(preferenceList);

    // Output the final board state
    cout << "Final Board State:" << endl;
    game.printBoard();

    // Output the moves you made
    cout << "Your Moves:" << endl;
    game.printYourMoves();

    return 0;
}