#include <iostream>
#include <stack>
#include <vector>
using namespace std;

class Grid
{
public:
    bool **grid;
    int rows, cols;

    Grid(int rows, int cols) : rows(rows), cols(cols)
    {
        // Allocate memory for the grid
        grid = new bool *[rows];

        for (int i = 0; i < rows; ++i)
        {
            grid[i] = new bool[cols];

            // Initialize all elements in the row to false (0)
            for (int j = 0; j < cols; ++j)
            {
                grid[i][j] = false; // Set to 0
            }
        }

        generateObstacles();
    }

    ~Grid()
    {
        // Deallocate memory
        for (int i = 0; i < rows; ++i)
        {
            delete[] grid[i];
        }
        delete[] grid;
    }

    // Function to generate obstacles randomly
    void generateObstacles()
    {
        int obstacles = (rows * cols) * 0.6; // 60% obstacles

        srand(time(NULL));

        while (obstacles > 0)
        {
            int x = rand() % rows;
            int y = rand() % cols;

            if (grid[x][y] == 0)
            {
                // Place an obstacle if the spot is empty
                grid[x][y] = 1;
                obstacles--;
            }
        }
    }

    bool checkStart(int startX, int startY)
    {
        if (grid[startX][startY] == 1)
            return true;
        else
            return false;
    }

    // Function to check if a position is within grid bounds and not an obstacle
    bool isValid(int x, int y, vector<vector<bool>> &visited)
    {
        return (x >= 0 && x < rows && y >= 0 && y < cols && grid[x][y] == 0 && !visited[x][y]);
    }

    bool pathExists(int startX, int startY, int endX, int endY)
    {
        if (checkStart(startX, startY) == false)
            return false;

        vector<vector<bool>> visited(rows, vector<bool>(cols, false));

        // Direction vectors for moving in all 8 possible directions
        int dx[] = {0, 1, 1, 1, 0, -1, -1, -1};
        int dy[] = {1, 1, 0, -1, -1, -1, 0, 1};

        stack<pair<int, int>> s;
        s.push({startX, startY});

        visited[startX][startY] = true;

        while (!s.empty())
        {
            int x = s.top().first;
            int y = s.top().second;
            s.pop();

            cout << x << " " << y << endl;

            // If we reached the destination, mark the path and return true
            if (x == endX && y == endY)
            {
                return true;
            }

            // Explore all 8 directions
            for (int i = 0; i < 8; ++i)
            {
                int newX = x + dx[i];
                int newY = y + dy[i];
                if (isValid(newX, newY, visited))
                {
                    visited[newX][newY] = true;
                    s.push({newX, newY});
                }
            }
        }

        return false; // If no path exists
    }

    // Function to display the grid
    void displayGrid()
    {
        cout << endl;
        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < cols; ++j)
            {
                cout << grid[i][j] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
};

int main()
{
    int rows, cols;

    cout << "Enter number of rows: ";
    cin >> rows;

    cout << "Enter number of cols: ";
    cin >> cols;

    Grid grid(rows, cols);
    grid.displayGrid();

    cout << "Rows range: 0 to " << rows - 1 << endl;
    cout << "Cols range: 0 to " << cols - 1 << endl;
    cout << endl;

    int startX, startY, endX, endY;

    // Validate startX and startY
    do
    {
        cout << "Enter starting point (x y): ";
        cin >> startX >> startY;

        if (startX < 0 || startX >= rows || startY < 0 || startY >= cols)
        {
            cout << "Invalid input. Start point must be within the grid (0 to "
                 << rows - 1 << " for X and 0 to " << cols - 1 << " for Y)." << endl;
        }

    } while (startX < 0 || startX >= rows || startY < 0 || startY >= cols);

    // Validate endX and endY
    do
    {
        cout << "Enter ending point (x y): ";
        cin >> endX >> endY;

        if (endX < 0 || endX >= rows || endY < 0 || endY >= cols)
        {
            cout << "Invalid input. End point must be within the grid and not exceed the start point." << endl;
        }

    } while (endX < 0 || endX >= rows || endY < 0 || endY >= cols);

    // grid.displayGrid();

    cout << endl;
    if (grid.pathExists(startX, startY, endX, endY))
    {
        cout << "Path exists!" << endl;
    }
    else
    {
        cout << "No path exists!" << endl;
    }
    cout << endl;

    return 0;
}