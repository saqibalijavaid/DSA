#include <iostream>
#include <string>

using namespace std;

void solve(int i, int j, int rows, int cols, char **grid);
int numIslands(int rows, int cols, char **grid);

char validateInput();
void takeInput(char **arr, int rows, int cols);
void printArray(char **arr, int rows, int cols);
void deallocateMemory(char **arr, int rows);

int main()
{
    int rows, cols;

    // Ask user for the size of the 2D array
    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    cout << endl;

    // Dynamically allocate the 2D array
    char **arr = new char *[rows];
    for (int i = 0; i < rows; ++i)
    {
        arr[i] = new char[cols];
    }

    // Take input for the 2D array
    takeInput(arr, rows, cols);

    // Print the 2D array
    printArray(arr, rows, cols);

    cout << endl;
    int output = numIslands(rows, cols, arr);
    cout << "The number of islands is " << output << "." << endl;
    cout << endl;

    // Deallocate the memory
    deallocateMemory(arr, rows);

    return 0;
}

void solve(int i, int j, int rows, int cols, char **grid)
{
    // 6 conditions
    if (i < 0 || i > rows - 1 || j < 0 || j > cols - 1 || grid[i][j] == '*' || grid[i][j] == '0')
        return;

    grid[i][j] = '*';

    solve(i + 1, j, rows, cols, grid); // Bottom
    solve(i - 1, j, rows, cols, grid); // Up
    solve(i, j + 1, rows, cols, grid); // Right
    solve(i, j - 1, rows, cols, grid); // Left
}

int numIslands(int rows, int cols, char **grid)
{
    // Loop through each element of matrix

    int counter = 0;

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (grid[i][j] == '1')
            {
                counter++;
                solve(i, j, rows, cols, grid);
            }
        }
    }

    return counter;
}

// ----------------------------------------------------------------

// Function to validate input, ensuring only '0' or '1' is accepted
char validateInput()
{
    string input;
    while (true)
    {
        cin >> input;
        if (input.length() == 1 && (input[0] == '0' || input[0] == '1'))
        {
            return input[0]; // Valid input, return the character
        }
        else
        {
            cout << "Invalid input! Please enter only a single '0' or '1': ";
        }
    }
}

// Function to take input for the 2D array
void takeInput(char **arr, int rows, int cols)
{
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            cout << "Enter a value for element [" << i << "][" << j << "] (0 or 1): ";
            arr[i][j] = validateInput(); // Use the validation function
        }
    }
}

// Function to print the 2D array
void printArray(char **arr, int rows, int cols)
{
    cout << endl;
    cout << "The 2D array is:" << endl;
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
}

// Function to deallocate the memory used by the 2D array
void deallocateMemory(char **arr, int rows)
{
    for (int i = 0; i < rows; ++i)
    {
        delete[] arr[i];
    }
    delete[] arr;
}