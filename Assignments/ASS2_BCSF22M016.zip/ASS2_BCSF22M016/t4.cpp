#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // Constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};

class Queue
{
    Node *head;
    Node *tail;

public:
    // Constructor
    Queue() : head(NULL), tail(NULL) {}

    // Destructor
    // All dynamically allocated nodes in the LL will be properly deleted when the Queue object is destroyed
    ~Queue()
    {
        while (head != NULL)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }

    void enqueue(int data) // Add an item to the end of the queue.
    {
        if (tail == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
        }
        else
        {
            Node *temp = new Node(data);
            tail->next = temp;
            temp->prev = tail;
            tail = temp;
        }
    }

    int dequeue() // Remove and return the item from the front of the queue.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }
        else
        {
            Node *temp = head;

            if (head->next == NULL) // if there is only one node
            {
                head = NULL;
                tail = NULL;
            }

            else
            {
                head = head->next;
                head->prev = NULL;
            }

            int toReturn = temp->data;
            temp->next = NULL;
            delete temp;
            return toReturn;
        }
    }

    int peekFront() // Return the item at the front of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return head->data;
    }
    int peekRear() // Return the item at the rear of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return tail->data;
    }
    bool isEmpty() // Check if the queue is empty.
    {
        return head == NULL && tail == NULL;
    }

    int size() // Return the number of items in the queue.
    {
        int count = 0;
        Node *temp = head;

        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        return count;
    }

    void print() // Prints the items in the queue.
    {
        Node *temp = head;

        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    Node *&getHead()
    {
        return head;
    }

    Node *&getTail()
    {
        return tail;
    }
};

class LRUCache
{
private:
    int capacity;
    Queue q;
    int pageHits, pageFaults;

public:
    LRUCache(int capacity)
    {
        this->capacity = capacity;
        this->pageHits = 0;
        this->pageFaults = 0;
    }

    void solve(int page)
    {
        bool found = false;
        int qSize = q.size();

        // Check if the page is already in the cache
        Node *temp = q.getHead();
        while (temp != NULL)
        {
            if (temp->data == page)
            {
                found = true;
                break;
            }

            temp = temp->next;
        }

        if (found)
        {
            // If the page is already in the cache
            pageHits++;

            // Move the page to the end of the queue (most recently used)
            if (temp->prev != NULL) // If it's not already the first node
                temp->prev->next = temp->next;

            if (temp->next != NULL) // If it's not already the last node
                temp->next->prev = temp->prev;

            // if (temp == q.getHead() && temp->next != NULL) // If the node was at the head, move the head pointer and it's not the only single node present
            if (temp == q.getHead()) // If the node was at the head, move the head pointer and it's not the only single node present
                q.getHead() = temp->next;

            if (temp != q.getTail()) // If it's not already the tail, move it to the tail
            {
                temp->prev = q.getTail();
                temp->next = NULL;
                q.getTail()->next = temp;
                q.getTail() = temp;
            }
        }
        else
        {
            // If the page is not present in the cache
            pageFaults++;

            // If size is full, remove the least recently used page (from the front)
            if (q.size() == capacity)
            {
                q.dequeue();
            }

            // Add the new page to the end of the queue (most recently used)
            q.enqueue(page);
        }
    }

    void displayHitsAndFaults()
    {
        cout << "Page Hits: " << pageHits << endl;
        cout << "Page Faults: " << pageFaults << endl;
    }
};

int main()
{
    int capacity;
    cout << "Enter the capacity of the LRU Cache: ";
    cin >> capacity;

    LRUCache cache(capacity);

    int page;
    cout << "Enter the sequence of page requests (end with -1):" << endl;
    while (cin >> page && page != -1)
    {
        cache.solve(page);
    }

    cache.displayHitsAndFaults();

    return 0;
}