#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // Constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};

class Queue
{
    Node *head;
    Node *tail;

public:
    // Constructor
    Queue() : head(NULL), tail(NULL) {}

    // Destructor
    // All dynamically allocated nodes in the LL will be properly deleted when the Queue object is destroyed
    ~Queue()
    {
        while (head != NULL)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }

    void enqueue(int data) // Add an item to the end of the queue.
    {
        if (tail == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
        }
        else
        {
            Node *temp = new Node(data);
            tail->next = temp;
            temp->prev = tail;
            tail = temp;
        }
    }

    int dequeue() // Remove and return the item from the front of the queue.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }
        else
        {
            Node *temp = head;

            if (head->next == NULL) // if there is only one node
            {
                head = NULL;
                tail = NULL;
            }

            else
            {
                head = head->next;
                head->prev = NULL;
            }

            int toReturn = temp->data;
            temp->next = NULL;
            delete temp;
            return toReturn;
        }
    }

    int peekFront() // Return the item at the front of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return head->data;
    }
    int peekRear() // Return the item at the rear of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return tail->data;
    }
    bool isEmpty() // Check if the queue is empty.
    {
        return head == NULL && tail == NULL;
    }

    int size() // Return the number of items in the queue.
    {
        int count = 0;
        Node *temp = head;

        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        return count;
    }

    void print() // Prints the items in the queue.
    {
        Node *temp = head;

        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

string eliminateConsecutiveDuplicates(string input)
{
    Queue q;

    for (int i = 0; i < input.length(); i++)
    {
        if (q.isEmpty())
            q.enqueue(input[i]);

        else
        {
            if (q.peekRear() == input[i])
                continue;
            else
                q.enqueue(input[i]);
        }
    }

    string output = "";

    while (!q.isEmpty())
    {
        output += q.peekFront();
        q.dequeue();
    }

    return output;
}

int main()
{
    string input;

    do
    {
        cout << "Enter a string (enter -1 to quit): ";
        getline(cin, input);

        if (input != "-1")
        {
            cout << "Input: " << input << endl;
            cout << "Output: " << eliminateConsecutiveDuplicates(input) << endl;
        }

    } while (input != "-1");

    cout << "Program Terminated!" << endl;

    return 0;
}

/*
We can use Stack in place of Queue but we will face difficulty in the 2nd loop.
In Stack, there is no function which can return the element from bottom.
In 2nd loop in case of stack, if we return the elements from top we will get the output string in reversed form.
*/