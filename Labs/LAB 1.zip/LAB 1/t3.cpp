#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *prev;
    Node *next;

    Node(int d)
    {
        this->data = d;
        Node *next = NULL;
        Node *prev = NULL;
    }
};

void deleteNthNodeFromTheEnd(Node *&head, int n)
{
    if (head == NULL || n <= 0)
        return;

    Node *first = head;
    Node *second = head;

    for (int i = 0; i < n; ++i) // 0<4 1<4 2<4 3<4
    {
        if (first == NULL) // n is greater than the length of the list
        {
            return;
        }

        cout << "Hello" << endl;
        first = first->next;
    }

    // Move both pointers together until first reaches the end
    while (first != NULL && first->next != NULL)
    {
        first = first->next;
        second = second->next;
    }

    // Now second is pointing to the node just before the node to be deleted

    Node *nodeToDelete = NULL;

    if (second == head && first == NULL)
    {
        // If we need to delete the head node itself
        nodeToDelete = head;
        head = head->next;
        if (head != NULL)
        {
            head->prev = NULL;
        }
    }

    else
    {
        nodeToDelete = second->next;
        second->next = nodeToDelete->next;

        if (nodeToDelete->next != NULL)
        {
            nodeToDelete->next->prev = second;
        }
    }

    delete nodeToDelete;
}

void insertAtHead(Node *&head, int d)
{
    // new node creation
    Node *temp = new Node(d);

    temp->next = head;
    head->prev = temp;
    head = temp;
}

void print(Node *&head)
{
    // new node creation
    Node *temp = head;

    while (temp != NULL)
    // while (temp)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    Node *node1 = new Node(20);
    Node *head = node1;

    print(head);

    insertAtHead(head, 15);
    print(head);

    insertAtHead(head, 10);
    print(head);

    insertAtHead(head, 5);
    print(head);

    cout << "Head: " << head->data << endl;

    deleteNthNodeFromTheEnd(head, 4);
    print(head);
}