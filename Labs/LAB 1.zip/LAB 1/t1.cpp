// Given a singly linked list, you have to reverse that singly linked list and return the head of that updated list.

#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    // constructor
    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }
};

Node *reverseSinglyLinkedList(Node *&head)
{
    Node *prev = NULL;
    Node *current = head;
    Node *next = NULL;

    while (current != NULL)
    {
        next = current->next; // Store next node
        current->next = prev; // Reverse current node's pointer

        // Move pointers one position ahead
        prev = current;
        current = next;
    }

    // Prev will now point to the new head after reversal
    head = prev;
    return head;
}

void insertAtHead(Node *&head, int d)
{
    // new node creation
    Node *temp = new Node(d);

    temp->next = head;
    head = temp;
}

void print(Node *&head)
{
    // new node creation
    Node *temp = head;

    while (temp != NULL)
    // while (temp)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    Node *node1 = new Node(20);
    Node *head = node1;

    print(head);

    insertAtHead(head, 15);
    print(head);

    insertAtHead(head, 10);
    print(head);

    insertAtHead(head, 5);
    print(head);

    cout << "\nAfter Reversal:" << endl;
    reverseSinglyLinkedList(head);
    print(head);

    cout << "Head: " << head->data << endl;
}