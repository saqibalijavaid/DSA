#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    // constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};

// Function to rearrange the linked list in zigzag fashion
void zigzagList(Node *&head)
{
    if (head == NULL || head->next == NULL)
        return;

    Node *current = head;
    bool lessExpected = true; // Start with '<' expectation

    while (current != NULL && current->next != NULL)
    {
        if (lessExpected)
        {
            // if current data is less than the next data
            if (current->data > current->next->data)
                swap(current->data, current->next->data);
        }
        else
        {
            // if current is greater than the next
            if (current->data < current->next->data)
                swap(current->data, current->next->data);
        }

        // Move to the next pair
        current = current->next;
        // if (current != NULL)
        //     current = current->next;

        // Switch the expectation for the next pair
        lessExpected = !lessExpected;
    }
}

void insertAtHead(Node *&head, int d)
{
    // new node creation
    Node *temp = new Node(d);

    temp->next = head;
    head = temp;
}

void print(Node *&head)
{
    // new node creation
    Node *temp = head;

    while (temp != NULL)
    // while (temp)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    Node *node1 = new Node(20);
    Node *head = node1;

    print(head);

    insertAtHead(head, 15);
    print(head);

    insertAtHead(head, 10);
    print(head);

    insertAtHead(head, 5);
    print(head);

    zigzagList(head);
    print(head);

    cout << "Head: " << head->data << endl;
}