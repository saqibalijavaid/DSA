#include <iostream>
#include <queue>
using namespace std;

class Patient
{
public:
    string name;
    string disorder;
    string registrationNo;
    int severity;

    // constructor
    Patient(string name, string disorder, string registrationNo, int severity)
        : name(name), disorder(disorder), registrationNo(registrationNo), severity(severity) {}

    bool operator<(const Patient &other) const
    {
        return severity < other.severity;
    }
};

class EmergencyRoom
{
private:
    priority_queue<Patient> pq;

public:
    void addPatient(const Patient &patient)
    {
        pq.push(patient);
    }

    Patient treatNextPatient()
    {
        if (!pq.empty())
        {
            Patient nextPatient = pq.top();
            pq.pop();
            return nextPatient;
        }
        else
        {
            cout << "No patients left for treatment" << endl;
        }
    }

    bool hasPatients() const
    {
        return !pq.empty();
    }

    void displayAllPatients() const
    {
        priority_queue<Patient> tempQueue = pq;

        while (!tempQueue.empty())
        {
            Patient p = tempQueue.top();
            tempQueue.pop();
            cout << "Name: " << p.name << " | Disorder: " << p.disorder << " | Registration No: " << p.registrationNo << " | Severity: " << p.severity << endl;
        }
    }
};

int main()
{
    EmergencyRoom er;

    er.addPatient(Patient("A", "Fever      ", "P01FE", 5));
    er.addPatient(Patient("D", "Cough      ", "P01CO", 1));
    er.addPatient(Patient("B", "Headache   ", "P01HA", 2));
    er.addPatient(Patient("C", "Stomachache", "P01SA", 3));
    
    er.displayAllPatients();
}