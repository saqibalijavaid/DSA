#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // Constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};

class FrontMiddleBack
{
    Node *head;
    Node *tail;

public:
    // Constructor
    FrontMiddleBack() : head(NULL), tail(NULL) {}

    // Destructor
    // All dynamically allocated nodes in the LL will be properly deleted when the Queue object is destroyed
    ~FrontMiddleBack()
    {
        while (head != NULL)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }

    void pushFront(int data) // Add an item to the front of the queue.
    {
        if (head == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
        }
        else
        {
            Node *temp = new Node(data);
            temp->next = head;
            head->prev = temp;
            temp->prev = tail;
            tail->next = temp;
            head = temp;
        }
    }

    // CDLL2 Queue
    void pushMiddle(int data) // Add an item to the Middle of the queue.
    {
        Node *insert = new Node(data);

        if (isEmpty())
        {
            head = insert;
            tail = insert;
            head->next = head->prev = head;
        }
        else
        {
            if (size() == 1)
            {
                pushBack(data);
            }

            int tempCount = size() / 2;

            Node *temp = head;

            while (tempCount > 0)
            {
                temp = temp->next;
                tempCount--;
            }

            insert->next = temp;
            insert->prev = temp->prev;
            temp->prev->next = insert;
            temp->prev = insert;
        }
    }

    void pushBack(int data) // Add an item to the end of the queue.
    {
        if (tail == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
        }
        else
        {
            Node *temp = new Node(data);
            tail->next = temp;
            temp->prev = tail;
            temp->next = head;
            head->prev = temp;
            tail = temp;
        }
    }

    int popFront() // Remove and return the item from the front of the queue.
    {
        if (isEmpty())
        {
            return -1;
        }

        Node *temp = head;
        int toReturn;

        if (head->next == head) // if there is only one node
        {
            head = tail = NULL;

            toReturn = temp->data;
        }

        else
        {
            head = head->next;

            head->prev = temp->prev;
            tail->next = temp->next;

            toReturn = temp->data;
        }

        temp->next = temp->prev = NULL;
        delete temp;

        return toReturn;
    }

    int popMiddle() // Remove and return the item from the Middle of the queue.
    {
        if (isEmpty())
        {
            return -1;
        }

        Node *temp = head;
        int toReturn;
        int currentSize = size();

        if (currentSize == 1) // if there is only one node
        {
            toReturn = temp->data;

            head = tail = NULL;
            delete temp;
            return toReturn;
        }

        else if (currentSize == 2)
        {
            return popBack();
        }

        int tempCount = currentSize / 2;
        Node *temp = head;

        while (tempCount > 0)
        {
            temp = temp->next;
            tempCount--;
        }

        toReturn = temp->data;

        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;

        delete temp;
        return toReturn;
    }

    int popBack() // Remove and return the item from the rear of the queue.
    {
        if (isEmpty())
        {
            return -1;
        }

        Node *temp = tail;
        int toReturn;

        if (tail->next == tail) // if there is only one node
        {
            head = tail = NULL;

            toReturn = temp->data;
        }

        else
        {
            tail = tail->prev;

            tail->next = temp->next;
            head->prev = temp->prev;

            toReturn = temp->data;
        }

        delete temp;
        temp->next = temp->prev = NULL;

        return toReturn;
    }

    int peekFront() // Return the item at the front of the queue without removing it.
    {
        if (isEmpty())
        {
            return -1;
        }

        return head->data;
    }
    int peekRear() // Return the item at the rear of the queue without removing it.
    {
        if (isEmpty())
        {
            return -1;
        }

        return tail->data;
    }
    bool isEmpty() // Check if the queue is empty.
    {
        return head == NULL && tail == NULL;
    }

    int size() // Return the number of items in the queue.
    {
        if (isEmpty())
        {
            return 0;
        }

        int count = 1;
        Node *temp = head->next;

        while (temp != head)
        {
            count++;
            temp = temp->next;
        }

        return count;
    }

    void print() // Prints the items in the queue.
    {
        Node *temp = head->next;

        cout << head->data << " ";

        while (temp != head)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    FrontMiddleBack q;
    int choice, value;

    cout << endl;
    cout << "--- Queue Implementation Using CDLL2 ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Push Front" << endl;
        cout << " 2. Push Middle" << endl;
        cout << " 3. Push Back" << endl;
        cout << " 4. Remove Front Element" << endl;
        cout << " 5. Remove Middle Element" << endl;
        cout << " 6. Remove Back Element" << endl;
        cout << " 7. Front Peek" << endl;
        cout << " 8. Back Peek" << endl;
        cout << " 9. Check if Queue is Empty" << endl;
        cout << " 10. Get Queue Size" << endl;
        cout << " 11. Print Queue" << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value to Push Front: ";
            cin >> value;
            q.pushFront(value);
            break;

        case 2:
            cout << "Enter value to Push Middle: ";
            cin >> value;
            q.pushMiddle(value);
            break;

        case 3:
            cout << "Enter value to Push Back: ";
            cin >> value;
            q.pushBack(value);
            break;

        case 4:
            cout << "Pop Front element: " << q.popFront() << endl;
            break;

        case 5:
            cout << "Pop Middle element: " << q.popMiddle() << endl;
            break;

        case 6:
            cout << "Pop Back element: " << q.popBack() << endl;
            break;

        case 7:
            try
            {
                cout << "Front Peek: " << q.peekFront() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 8:
            try
            {
                cout << "Rear Peek: " << q.peekRear() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 9:
            if (q.isEmpty())
                cout << "Queue is empty." << endl;
            else
                cout << "Queue is not empty." << endl;
            break;

        case 10:
            cout << "Size of queue: " << q.size() << endl;
            break;

        case 11:
            q.print();
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}