#include <iostream>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    // Constructor
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

int findKthAncestorHelper(TreeNode *root, int target, int &K, int &ancestor)
{
    if (root == NULL)
    {
        return -1;
    }

    // TARGET FOUND
    if (root->val == target)
    {
        return root->val;
    }

    int left = findKthAncestorHelper(root->left, target, K, ancestor);
    int right = findKthAncestorHelper(root->right, target, K, ancestor);

    // If the target node is found in either subtree
    if (left != -1 || right != -1)
    {
        K--;

        if (K == 0)
        {
            ancestor = root->val;
            return root->val;
        }

        return root->val;
    }

    return -1;
}

int findKthAncestor(TreeNode *root, int target, int &K)
{
    int ancestor = -1;
    findKthAncestorHelper(root, target, K, ancestor);
    return ancestor;
}

int main()
{
    TreeNode *root = new TreeNode(8);
    root->left = new TreeNode(3);
    root->right = new TreeNode(10);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(6);
    root->left->right->left = new TreeNode(4);
    root->left->right->right = new TreeNode(7);
    root->right->right = new TreeNode(14);
    root->right->right->left = new TreeNode(13);

    int K = 3;
    int target = 13;
    int output = findKthAncestor(root, target, K);

    cout << output << endl;

    return 0;
}
