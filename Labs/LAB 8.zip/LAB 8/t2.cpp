#include <iostream>
using namespace std;

// Definition for a binary tree node.
class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

bool isIdentical(TreeNode *t1, TreeNode *t2)
{
    if (t1 == NULL && t2 == NULL)
        return true;

    if (t1 == NULL || t2 == NULL)
        return false;

    // If the values of the nodes are the same, check the subtrees
    return (t1->val == t2->val &&
            isIdentical(t1->left, t2->left) &&
            isIdentical(t1->right, t2->right));
}

bool isSubtree(TreeNode *t1, TreeNode *t2)
{
    if (t2 == NULL)
        return true;

    if (t1 == NULL)
        return false;

    // If t1 and t2 are identical from the current node, return true
    if (isIdentical(t1, t2))
        return true;

    return isSubtree(t1->left, t2) || isSubtree(t1->right, t2);
}

int main()
{
    TreeNode *t1 = new TreeNode(3);
    t1->left = new TreeNode(4);
    t1->right = new TreeNode(5);
    t1->left->left = new TreeNode(1);
    t1->left->right = new TreeNode(2);

    TreeNode *t2 = new TreeNode(4);
    t2->left = new TreeNode(1);
    t2->right = new TreeNode(2);

    if (isSubtree(t1, t2))

    
}