#include <iostream>
#include <string>

using namespace std;

class Node
{
public:
    char data;
    Node *next;

    // constructor
    Node(char data) : data(data), next(nullptr) {}
};

class Stack
{
    Node *top;

public:
    Stack() : top(nullptr) {}

    void push(char data)
    {
        Node *temp = new Node(data);
        temp->next = top;
        top = temp;
    }

    void pull()
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack Underflow");
        }
        Node *temp = top;
        top = top->next;
        delete temp;
    }

    char peek() const
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack is empty!");
        }
        return top->data;
    }

    bool isEmpty() const
    {
        return top == nullptr;
    }

    int size() const
    {
        Node *temp = top;
        int count = 0;
        while (temp != nullptr)
        {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

string getLargestNumber(string N, int K)
{
    Stack s;
    int toRemove = K;

    for (char c : N) // for-each loop
    {
        // Remove characters from the stack if the current character is greater
        // and toRemove is greater than Zero
        while (!s.isEmpty() && toRemove > 0 && s.peek() < c)
        {
            s.pull();
            toRemove--;
        }
        s.push(c);
    }

    // If there are still characters to remove, remove them from the top
    while (toRemove > 0)
    {
        s.pull();
        toRemove--;
    }

    // Resulting number from the stack
    if (s.isEmpty())
        return "0";

    string result = "";
    while (!s.isEmpty())
    {
        result = s.peek() + result;
        s.pull();
    }

    return result;
}

int main()
{
    string N;
    int K;

    cout << "Enter the number: ";
    cin >> N;

    cout << "Enter the number of digits to delete: ";
    cin >> K;

    string result = getLargestNumber(N, K);
    cout << "The largest number possible is: " << result << endl;

    return 0;
}
