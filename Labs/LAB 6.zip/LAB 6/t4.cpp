#include <iostream>
#include <stack>
#include <vector>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int data = 0, Node *nextInput = NULL)
    {
        this->data = data;
        next = nextInput;
    }
    void print(Node *head)
    {
        if (head == NULL)
        {
            cout << "List is empty." << endl;
            return;
        }
        Node *temp = head;
        while (temp)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

vector<int> processQueries(int *queries, int size, int m)
{

    // vector<int> mm;
    Node *temp = new Node(1);

    Node *head = temp;
    for (int i = 2; i <= m; i++)
    {
        temp->next = new Node(i);
        temp = temp->next;
    }

    cout << "1 to m:" << endl;
    head->print(head);

    temp = head;
    vector<int> ans;
    int count = 0;
    for (int i = 0; i < size; i++)
    {
        int toFind = queries[i];
        Node *newNode = new Node(toFind);

        Node *prev = NULL;
        temp = head;

        while (temp)
        {
            if (toFind == temp->data)
            {
                ans.push_back(count);
                count = 0;

                if (prev == NULL)
                {
                    newNode->next = temp;
                    head = newNode;
                }
                else
                {
                    prev->next = temp->next;
                    // cout<<temp->data<<endl;
                    newNode->next = head;
                    head = newNode;
                }
                break;
            }
            else
            {
                prev = temp;
            }
            temp = temp->next;
            count++;
        }
    }
    return ans;
}

int main()
{
    int arr[4] = {4, 1, 2, 2};

    int m = 4;
    vector<int> ans = processQueries(arr, 4, m);

    cout << "Output:" << endl;
    for (int i = 0; i < ans.size(); i++)
    {
        cout << ans[i] << " ";
    }
    cout << endl;

    return 0;
}