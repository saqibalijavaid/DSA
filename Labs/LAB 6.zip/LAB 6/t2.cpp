#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int dataInput = 0, Node *nextInput = NULL)
    {
        data = dataInput;
        next = nextInput;
    }
    void print(Node *head)
    {
        if (head == NULL)
        {
            cout << "List is empty." << endl;
            return;
        }
        Node *temp = head;
        while (temp)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

class SLL
{
private:
    Node *head;

public:
    SLL() : head(NULL) {}

    ~SLL()
    {
        while (head != NULL)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }

    Node *getHead() const
    {
        return head;
    }

    void setHead(Node *newHead)
    {
        head = newHead;
    }

    void insertionAtFirst(int value)
    {
        Node *newNode = new Node(value, head);
        head = newNode;
        cout << "Inserted " << value << " at the beginning." << endl;
    }

    void append(int value)
    {
        if (head == NULL)
        {
            head = new Node(value);
            cout << "Appended " << value << " as the first element." << endl;
            return;
        }
        Node *temp = head;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = new Node(value);
        cout << "Appended " << value << " to the end of the list." << endl;
    }

    void print()
    {
        if (head == NULL)
        {
            cout << "List is empty." << endl;
            return;
        }
        Node *temp = head;
        while (temp)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

Node *doubleIT(Node *head)
{
    Node *temp = head;
    int integer = temp->data;

    if (head == NULL)
    {
        return NULL;
    }

    // Convert List data to String
    string collect = "";
    while (temp)
    {
        collect = collect + to_string(temp->data);
        temp = temp->next;
    }

    // Now convert string to int and multiply by 2
    int num = stoi(collect);
    num = num * 2;

    // Convert Integer back to string
    collect = to_string(num);

    // Put all the digits from string to List
    int length = collect.size();
    temp = head;
    temp->data = (collect[0] - '0');

    for (int i = 1; i < length; i++)
    {
        if (temp->next == NULL)
        {
            temp->next = new Node(collect[i] - '0');
        }
        else
        {
            temp->next = new Node(collect[i] - '0');
        }

        temp = temp->next;
    }

    head->print(head);

    return head;
}

int main()
{
    SLL list;
    int n;
    do
    {
        cout << "Enter elements(-1 to exit):" << endl;
        cin >> n;

        if (n == -1)
            break;

        list.append(n);

    } while (n != -1);

    // list.insertionAtFirst(9);
    // list.insertionAtFirst(9);
    // list.insertionAtFirst(9);

    cout << "Current Number is : ";
    list.print();

    Node *temp = doubleIT(list.getHead());
    temp->print(temp);

    return 0;
}