#include <iostream>
using namespace std;

int oneDmapping(int rows, int columns, int startRow, int startColumn, int noOfCols)
{
    int m = noOfCols;

    // [i-Lr * (Uc-Lc+1)] + (j-Lc)

    // i is the row index.    -> rows
    // Lr is the lower row.   -> startRow
    // j is the column index. -> cols
    // Lc is the lower col.   -> startCol

    // m is the number of columns.

    int index = (rows - startRow) * m + (columns - startColumn);
    return index;
}

int main(void)
{
    int s = -1, k = 5;

    int rows = 3, cols = 4;
    // cout << "Enter no of rows: ";
    // cin >> rows;
    // cout << "Enter no of cols: ";
    // cin >> cols;

    cout << "Rows Range: " << s << " to " << s + rows << endl;
    cout << "Cols Range: " << k << " to " << k + cols << endl;

    int rowIndex = 0, colIndex = 7;
    cout << oneDmapping(rowIndex, colIndex, s, k, cols) << endl;

    return 0;
}