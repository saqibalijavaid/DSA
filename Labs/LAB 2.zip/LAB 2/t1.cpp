#include <iostream>
using namespace std;

class CDLL
{
public:
    int data;
    CDLL *next;
    CDLL *prev;

    // constructor
    CDLL(int d) : data(d), next(NULL), prev(NULL) {}
};

void insertCDLL(CDLL *&head, int value, int data)
{
    // if list is empty
    if (head == NULL)
    {
        CDLL *temp = new CDLL(data);

        head = temp;
        temp->next = temp;
        temp->prev = temp;
    }
    else
    {
        // assuming that the "int value" will be present in list
        // non-empty list

        CDLL *current = head;

        while (current->data != value)
        {
            current = current->next;
        }

        CDLL *temp = new CDLL(data);

        temp->next = current->next;
        current->next->prev = temp;
        current->next = temp;
        temp->prev = current;
    }
}

int removeMthCDLLs(CDLL *&head, int m)
{  // If there is no node in List
    if (
  head == nullptr)
    {
        cerr << "Empty list!\n";
        return -1;
    }

    // Find Size of List
    int size = 0;
    CDLL *temp = head;
    do
    {
        size++;
        head = head->next;

    } while (head != temp);

    CDLL *current = head;
    while (size > 1) // Traverse and delete nodes until only one remains
    {
        // Move m steps ahead
        for (int i = 1; i < m; ++i)
        {
            current = current->next;
        }

        // Remove current Node
        CDLL *prev = current->prev;
        CDLL *next = current->next;
        prev->next = next;
        next->prev = prev;

        // Adjust head if current is head
        if (current == head)
        {
            head = next;
        }

        CDLL *toDelete = current;
        current = next;

        delete toDelete;
        size--;
    }

    return head->data;
}

void print(CDLL *head)
{
    // empty list
    if (head == NULL)
    {
        cout << "Empty List, statement from print func!" << endl;
    }
    else
    {
        CDLL *temp = head;
        do
        {
            cout << head->data << " ";
            head = head->next;

        } while (head != temp);
        cout << endl;
    }
}

int main(void)
{
    CDLL *head = NULL;

    // print(head);

    insertCDLL(head, 0, 1);
    insertCDLL(head, 1, 2);
    insertCDLL(head, 2, 3);
    insertCDLL(head, 3, 4);
    insertCDLL(head, 4, 5);
    insertCDLL(head, 5, 6);
    insertCDLL(head, 6, 7);

    print(head);
    cout << endl;

    removeMthCDLLs(head, 2);

    cout << "After Deletion: " << endl;
    print(head);
}