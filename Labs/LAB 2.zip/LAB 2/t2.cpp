#include <iostream>
using namespace std;

class Stack
{
public:
    int *arr;
    int size;
    int top;

    // constructor
    Stack() {}
    Stack(int size)
    {
        this->size = size;
        arr = new int[size];
        top = -1;
    }

    void push(int element)
    {
        // if(size-1 > top)
        if (size - top > 1)
        {
            top++;
            arr[top] = element;
        }
        else
        {
            cout << "Stack Overflow!" << endl;
        }
    }

    void pull()
    {
        if (top >= 0)
        {
            top--;
        }
        else
        {
            cout << "Stack Underflow!" << endl;
        }
    }

    int peek()
    {
        if (top >= 0)
        {
            return arr[top];
        }
        else
        {
            cout << "Stack is empty!" << endl;
            return -1;
        }
    }

    bool isEmpty()
    {
        if (top == -1)
        {
            return true;
        }
        else
            return false;
    }
};

Stack sortStack(Stack s)
{
    Stack temp(6);

    while (!s.isEmpty())
    {
        // pull the top element from the s stack
        int tmp = s.peek();
        s.pull();

        // Insert tmp into temp stack
        while (!temp.isEmpty() && temp.peek() > tmp)
        {
            s.push(temp.peek());
            temp.pull();
        }

        temp.push(tmp);
    }

    // Copy the sorted elements from temp stack to the s stack
    while (!temp.isEmpty())
    {
        s.push(temp.peek());
        temp.pull();
    }

    return s;
}

void print(Stack s)
{
    while (!s.isEmpty())
    {
        cout << s.peek() << " ";
        s.pull();
    }

    cout << endl;
}

int main(void)
{
    Stack s(6);

    s.push(34);
    s.push(3);
    s.push(31);
    s.push(98);
    s.push(92);
    s.push(23);

    print(s);

    sortStack(s);

    print(s);
}