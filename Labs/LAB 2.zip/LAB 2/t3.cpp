#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    // constructor
    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }

    // destructor
    ~Node()
    {
        int value = this->data;

        if (this->next != NULL)
        {
            cout << "Inside if destructor condition!" << endl;
            this->next = NULL;
            delete next;
            // this->next = NULL;
        }

        cout << "Memory is free for node with data " << value << endl;
    }
};

void insertAtHead(Node *&head, int d)
{
    // new node creation
    Node *temp = new Node(d);

    temp->next = head;
    head = temp;
}

void insertAtTail(Node *&tail, int d)
{
    // new node creation
    Node *temp = new Node(d);

    tail->next = temp;
    tail = temp;
}

void insertAtPosition(Node *&head, Node *&tail, int pos, int d)
{
    if (pos == 1)
    {
        insertAtHead(head, d);
        return;
    }

    // new node creation
    Node *temp = head;
    int count = 1;

    while (count < pos - 1)
    {
        temp = temp->next;
        count++;
    }

    if (temp->next == NULL)
    {
        insertAtTail(tail, d);
        return;
    }

    Node *nodeToInsert = new Node(d);

    nodeToInsert->next = temp->next;
    temp->next = nodeToInsert;
}

void print(Node *&head)
{
    // new node creation
    Node *temp = head;

    while (temp != NULL)
    // while (temp)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

bool isPalindrom(Node *&head)
{
    Node *temp = head;

    Node *slow = head;
    Node *fast = head;

    // Step1: Divide into two parts
    while (fast != NULL && fast->next != NULL)
    {
        slow = slow->next;
        fast = fast->next->next;
    }
    // cout<<"second Part: ";
    // display(slow);

    // Step2: reverse second part
    Node *curr = slow;
    Node *prev = NULL;
    while (curr != NULL)
    {
        Node *nextNode = curr->next;
        curr->next = prev;
        prev = curr;
        curr = nextNode;
    }

    // Step3: Compare
    Node *firstHead = head;
    Node *secondHead = prev;
    while (secondHead)
    {
        if (firstHead->data != secondHead->data)
        {
            // cout<<"Not"<<endl;
            return false;
        }
        firstHead = firstHead->next;
        secondHead = secondHead->next;
    }
    // cout<<"Palindrome"<<endl;
    return true;
}

int main()
{
    Node *head = new Node(1);

    insertAtHead(head, 2);
    insertAtHead(head, 2);
    insertAtHead(head, 1);
    cout << "List:" << endl;
    print(head);

    if (isPalindrom(head))
    {
        cout << "Yes it is palindrome" << endl;
    }
    else
    {
        cout << "No, it is palindrome" << endl;
    }
}