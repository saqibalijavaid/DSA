#include <iostream>
using namespace std;

int minOperations(int *nums, int size)
{
    int length = size - 1;
    int maximum = nums[length];
    int turns = 0;
    for (int i = length; i >= 0; i--)
    {
        if (nums[i] > maximum)
        {
            if (nums[i] % maximum == 0)
            {
                int modulus = nums[i] / maximum;
                turns += modulus - 1;
                // cout<<turns<<endl;
            }
            else
            {
                int modulus = (nums[i] / maximum);
                turns += modulus + 1;
            }
        }

        maximum = nums[i];
    }
    // cout<<turns<<endl;
    return turns;
}

int main(void)
{
    int n;
    do
    {
        cout << "Enter the size of array (-1 to exit): ";
        cin >> n;
        if (n == -1)
            break;

        int *arr = new int[n];

        cout << "Enter Array elements:" << endl;
        for (int i = 0; i < n; i++)
        {
            cout << "Element " << i + 1 << ": ";
            cin >> arr[i];
        }

        cout << "Minimum operations for input array will be: " << minOperations(arr, n) << endl;
        cout << endl;
    } while (n != -1);
}