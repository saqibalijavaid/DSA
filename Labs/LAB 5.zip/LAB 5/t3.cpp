#include <iostream>
#include <stack>

using namespace std;

int clumsyFactorial(int n)
{
    int answer = 0;
    stack<int> s;
    s.push(n--);

    int index = 0;
    while (n > 0)
    {
        if (index % 4 == 0) // *
        {
            s.top() *= n;
        }
        else if (index % 4 == 1) // divide
        {
            s.top() /= n;
        }
        else if (index % 4 == 2) // +
        {
            s.push(n);
        }
        else // -
        {
            s.push(-n);
        }
        n--;
        index++;
    }

    while (!s.empty())
    {
        answer += s.top();
        s.pop();
    }

    return answer;
}

int main(void)
{
    int n;
    do
    {
        cout << "Enter the value of n (-1 to exit): ";
        cin >> n;
        if (n == -1)
            break;

        int ans = clumsyFactorial(n);
        cout << "Clumsy Factorial is: " << ans << endl;
        // clumsyFactorial(n);

    } while (n != -1);
}
