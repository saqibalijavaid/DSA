#include <iostream>
#include <queue>
using namespace std;

int farthestBuilding(int *heights, int n, int bricks, int ladders)
{
    priority_queue<int, vector<int>, greater<int>> pQueue;

    for (int i = 0; i < n - 1; ++i)
    {
        int diff = heights[i + 1] - heights[i];

        if (diff > 0)
        {
            pQueue.push(diff);

            if (pQueue.size() > ladders)
            {
                int smallestDiff = pQueue.top();
                pQueue.pop();
                bricks -= smallestDiff;

                if (bricks < 0)
                {
                    return i;
                }
            }
        }
    }

    return n - 1;
}

int main(void)
{
    int n;
    do
    {
        cout << "Enter the size of array (-1 to exit): ";
        cin >> n;
        if (n == -1)
            break;

        int *arr = new int[n];

        cout << "Enter Array elements:" << endl;
        for (int i = 0; i < n; i++)
        {
            cout << "Element " << i + 1 << ": ";
            cin >> arr[i];
        }

        int ladders, bricks;
        cout << "Enter num of bricks: ";
        cin >> bricks;
        cout << "Enter num of ladders: ";
        cin >> ladders;

        cout << "Farthest building we can reach: " << farthestBuilding(arr, n, bricks, ladders) << endl;
        cout << endl;

    } while (n != -1);
}
