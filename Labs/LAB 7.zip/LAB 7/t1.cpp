#include <iostream>
#include <cstdlib>
using namespace std;

class TreeNode
{
public:
    int val;
    TreeNode *left;
    TreeNode *right;

    TreeNode(int val)
    {
        this->val = val;
        this->right = NULL;
        this->right = NULL;
    }
};

int findTiltHelper(TreeNode *root, int &tilt)
{
    if (!root)
        return 0;

    int leftSum = findTiltHelper(root->left, tilt);
    int rightSum = findTiltHelper(root->right, tilt);

    tilt = tilt + abs(leftSum - rightSum);

    return root->val + leftSum + rightSum;
}

int findTilt(TreeNode *root)
{
    int tilt = 0;
    findTiltHelper(root, tilt);
    return tilt;
}

int main(void)
{
    TreeNode *root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);

    cout << "Total Tilt: " << findTilt(root) << endl;
}
