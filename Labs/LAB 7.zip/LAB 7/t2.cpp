#include <iostream>
#include <vector>
#include <queue> // For Level Order Traversal
#include <limits> // INT_MIN
#include <climits> // INT_MIN
using namespace std;

class Node
{
public:
    int data;
    Node *left;
    Node *right;

    Node(int dataI = 0)
    {
        data = dataI;
        this->right = NULL;
        this->right = NULL;
    }
};

vector<int> leftSubarray(int index, vector<int> array, int size)
{
    vector<int> left;

    for (int i = 0; i < index; i++)
    {
        left.push_back(array[i]);
    }

    return left;
}

vector<int> rightSubarray(int index, vector<int> array, int size)
{
    vector<int> right;

    for (int i = index + 1; i < size; i++)
    {
        right.push_back(array[i]);
    }

    return right;
}

int maximum(vector<int> array, int size)
{
    int maximum = INT_MIN;
    int index = -1;
    for (int i = 0; i < size; i++)
    {
        if (array[i] > maximum)
        {
            maximum = array[i];
            index = i;
        }
    }
    return index;
}

Node *createTree(vector<int> array, int size)
{
    if (size == 0)
        return NULL;

    int index = maximum(array, size);
    Node *tree = new Node(array[index]);

    vector<int> left = leftSubarray(index, array, size);
    vector<int> right = rightSubarray(index, array, size);

    tree->left = createTree(left, left.size());
    tree->right = createTree(right, right.size());

    // These two conditions will make NULL nodes, where there will be no nodes
    // These will occur in backtracking in each step of recursion

    if (tree->left == NULL && tree->right != NULL)
    {
        tree->left = new Node(-1);
    }

    if (tree->right == NULL && tree->left != NULL)
    {
        tree->right = new Node(-1);
    }

    return tree;
}

void levelOrderTraversal(Node *root)
{
    if (root == NULL)
    {
        return;
    }

    queue<Node *> q;
    q.push(root);

    while (!q.empty())
    {
        Node *temp = q.front();
        q.pop();

        cout << temp->data << " ";

        if (temp->left)
            q.push(temp->left);
        if (temp->right)
            q.push(temp->right);
    }
}

Node *newNode(int data)
{
    Node *NewNode = new Node(data);
    return (NewNode);
}

int main(void)
{
    Node *root = newNode(1);

    root->left = newNode(2);
    root->right = newNode(3);
    root->left->left = newNode(4);
    root->left->right = newNode(5);

    vector<int> array = {3, 2, 1, 6, 0, 5};

    Node *tree = createTree(array, array.size());

    levelOrderTraversal(tree);

    cout << endl;
}
