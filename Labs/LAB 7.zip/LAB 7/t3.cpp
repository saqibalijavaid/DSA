#include <iostream>
using namespace std;

void displayParenthesizedView(const int tree[], int size, int index = 0)
{
    if (index >= size || tree[index] == -1)
        return;

    cout << tree[index];

    if ((2 * index + 1 < size && tree[2 * index + 1] != -1) ||
        (2 * index + 2 < size && tree[2 * index + 2] != -1))
    {
        cout << "(";

        if (2 * index + 1 < size && tree[2 * index + 1] != -1)
        {
            displayParenthesizedView(tree, size, 2 * index + 1);
        }

        cout << ",";

        if (2 * index + 2 < size && tree[2 * index + 2] != -1)
        {
            displayParenthesizedView(tree, size, 2 * index + 2);
        }

        cout << ")";
    }
}

int main(void)
{
    int tree[] = {5,-1,7,-1,-1,6,3};
    int size = sizeof(tree) / sizeof(tree[0]);

    displayParenthesizedView(tree, size);
}
