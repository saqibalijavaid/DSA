#include <iostream>
#include <stdexcept>

using namespace std;

class Node
{
public:
    int data;
    Node *next;

    // Constructor
    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }

    // destructor
    ~Node()
    {
        // int toDelete = this->data;

        if (this->next != NULL)
        {
            this->next = NULL;
            delete this;
        }

        // cout << "Value to be deleted: " << toDelete << endl;
    }
};
class Stack
{
    Node *top;

public:
    Node *head;
    Node *tail;

    // constructor
    Stack()
    {
        this->top = NULL;
        this->head = NULL;
        this->tail = NULL;
    }

    void push(int data)
    {
        if (head == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
            top = tail;
        }
        else
        {
            Node *temp = new Node(data);

            tail->next = temp;
            temp->next = NULL;
            tail = temp;
            top = tail;
        }
    }

    void pull()
    {
        if (top == NULL)
        {
            cout << "Stack Underflowed" << endl;
        }
        else if (head == tail)
        {
            delete head;
            top = NULL;
            head = NULL;
            tail = NULL;
        }
        else
        {
            Node *previous = NULL;
            Node *current = head;

            while (current != tail)
            {
                previous = current;
                current = current->next;
            }

            tail = previous;
            top = tail;

            if (previous != NULL)
            {
                previous->next = NULL;
            }

            delete current;
        }
    }

    int peek()
    {
        if (top != NULL)
            return top->data;
        else
            throw runtime_error("Stack is empty!");
    }

    bool isEmpty()
    {
        if (top == NULL)
            return true;
        else
            return false;
    }
};

class Queue
{
private:
    Stack s1; // For enqueue
    Stack s2; // For dequeue

public:
    // Constructor
    Queue() {}

    void enQueue(int x)
    {
        s1.push(x);
    }

    int deQueue()
    {
        if (isEmpty())
        {
            throw runtime_error("Queue is empty");
        }

        if (s2.isEmpty())
        {
            // Transfer elements from s1 to s2 to reverse the order
            while (!s1.isEmpty())
            {
                s2.push(s1.peek());
                s1.pull();
            }
        }

        int front = s2.peek();
        s2.pull();
        return front;
    }

    bool isEmpty()
    {
        if (s1.isEmpty() && s2.isEmpty())
            return true;
        else
            return false;
    }
};

int main()
{
    Queue q;
    q.enQueue(1);
    q.enQueue(2);
    q.enQueue(3);

    cout << q.deQueue() << " ";
    cout << q.deQueue() << " ";
    cout << q.deQueue() << " ";

    cout << endl;
}
