#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;
class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }

    // destructor
    ~Node()
    {
        // int toDelete = this->data;

        if (this->next != NULL)
        {
            this->next = NULL;
            delete this;
        }

        // cout << "Value to be deleted: " << toDelete << endl;
    }
};

class Stack
{
    Node *top;

public:
    Node *head;
    Node *tail;

    // public:
    // constructor
    Stack()
    {
        this->top = NULL;
        this->head = NULL;
        this->tail = NULL;
    }

    void push(int data)
    {
        if (head == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
            top = tail;
        }
        else
        {
            Node *temp = new Node(data);

            tail->next = temp;
            temp->next = NULL;
            tail = temp;
            top = tail;
        }
    }

    void pull()
    {
        if (top == NULL)
        {
            cout << "Stack Underflowed" << endl;
        }
        else if (head == tail)
        {
            delete head;
            top = NULL;
            head = NULL;
            tail = NULL;
        }
        else
        {
            Node *previous = NULL;
            Node *current = head;

            while (current != tail)
            {
                previous = current;
                current = current->next;
            }

            tail = previous;
            top = tail;

            if (previous != NULL)
            {
                previous->next = NULL;
            }

            delete current;
        }
    }

    int peek()
    {
        if (top != NULL)
            return top->data;
        else
            throw runtime_error("Stack is empty!");
    }

    bool isEmpty()
    {
        if (top == NULL)
            return true;
        else
            return false;
    }
};

int precedent(char c)
{
    if (c == '*' || c == '/')
    {
        return 2;
    }
    else if (c == '+' || c == '-')
    {
        return 1;
    }
    return -1;
}

string infixToPostfix(string str)
{
    Stack st;
    string postfix = "";

    for (int i = 0; i < str.length(); i++)
    {
        // Operand
        if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= '0' && str[i] <= '9'))
        {
            while (i < str.length() && ((str[i] >= '0' && str[i] <= '9') || (str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z')))
            {
                postfix += str[i];
                i++;
            }
            postfix += ' ';
            i--;
        }

        // Opening parenthesis
        else if (str[i] == '(')
        {
            st.push(str[i]);
        }

        // Closing parenthesis
        else if (str[i] == ')')
        {
            while (!st.isEmpty() && st.peek() != '(')
            {
                postfix += st.peek();
                postfix += ' ';
                st.pull();
            }
            if (!st.isEmpty())
            {
                st.pull();
            }
        }
        // Operator
        else
        {
            while (!st.isEmpty() && precedent(str[i]) <= precedent(st.peek()))
            {
                postfix += st.peek();
                postfix += ' ';
                st.pull();
            }
            st.push(str[i]);
        }
    }

    while (!st.isEmpty())
    {
        postfix += st.peek();
        postfix += ' ';
        st.pull();
    }

    return postfix;
}

int postfixEvaluation(string str)
{
    Stack st;
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == ' ')
        {
            continue;
        }
        else if (isdigit(str[i]))
        {
            int num = 0;
            while (i < str.length() && isdigit(str[i]))
            {
                num = num * 10 + (str[i] - '0');
                i++;
            }
            st.push(num);
            i--;
        }
        else
        {
            int right = st.peek();
            st.pull();
            int left = st.peek();
            st.pull();
            switch (str[i])
            {
            case '+':
                st.push(left + right);
                break;
            case '-':
                st.push(left - right);
                break;
            case '*':
                st.push(left * right);
                break;
            case '/':
                st.push(left / right);
                break;
            }
        }
    }
    return st.peek();
}

int main()
{
    string infix;
    int exit = -1;

    while (true)
    {
        cout << "Enter an arithmetic expression in infix notation, or enter '-1' to exit:" << endl;
        getline(cin, infix);

        if (stoi(infix) == exit)
        {
            break;
        }

        cout << "Infix: " << infix << endl;

        string postfix = infixToPostfix(infix);
        cout << "Postfix: " << postfix << endl;

        int result = postfixEvaluation(postfix);
        cout << "Result: " << result << endl;
    }
}
