// In deleteNodeWithValuesKthOccurrence function, deleting last node is giving segmentation fault

#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // Constructor
    // Node(int d) : data(d), next(NULL), prev(NULL) {}

    Node(int d)
    {
        this->data = d;
        this->next = NULL;
        this->prev = NULL;
    }

    ~Node()
    {
        int value = this->data;

        if (this->next != NULL || this->prev != NULL)
        {
            cout << "Inside if destructor condition!" << endl;
            this->next = NULL;
            this->prev = NULL;
            delete next;
            delete prev;
        }

        cout << "Memory is free for node with data " << value << endl;
    }
};

void print(Node *&head)
{
    Node *temp = head;

    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void insertAtHead(Node *&head, int d)
{
    Node *temp = new Node(d);

    temp->next = head;
    head->prev = temp;
    head = temp;
}

void insertAtTail(Node *&tail, int d)
{
    Node *temp = new Node(d);

    temp->prev = tail;
    tail->next = temp;
    tail = temp;
}

void insertAtPosition(Node *&head, Node *&tail, int pos, int d)
{
    if (pos == 1)
    {
        insertAtHead(head, d);
        return;
    }

    Node *temp = head;
    int count = 1;

    while (count < pos - 1)
    {
        temp = temp->next;
        count++;
    }

    if (temp->next == NULL)
    {
        insertAtTail(tail, d);
        return;
    }

    // cout << "Count: " << count << endl;

    Node *nodeToInsert = new Node(d);

    nodeToInsert->next = temp->next;
    nodeToInsert->prev = temp;
    temp->next->prev = nodeToInsert;
    temp->next = nodeToInsert;
}

void deleteNodeWithPos(Node *&head, Node *&tail, int pos)
{
    // deleting 1st node
    if (pos == 1)
    {
        Node *temp = head;

        // update head
        head = head->next;
        head->prev = NULL;

        // now free memory
        temp->next = NULL;
        delete temp;
    }
    // deleting any middle or last node
    else
    {
        Node *current = head;  // in start it will point to 1st node
        Node *previous = NULL; // in start as there is no node before 1st node so it will point to NULL

        int count = 1;

        while (count < pos)
        {
            previous = current;
            current = current->next;

            count++;
        }

        if (current->next == NULL)
        {
            tail = previous;
            previous->next = NULL;
        }
        else
        {
            previous->next = current->next;
            current->next->prev = previous;
        }

        current->next = NULL;
        current->prev = NULL;
        delete current;
    }
}

void deleteNodeWithValue(Node *&head, Node *&tail, int value)
{
    // List is Empty
    if (head == NULL)
        return;

    int pos = 1;
    Node *temp = head;

    while (temp != NULL && temp->data != value)
    {
        temp = temp->next;
        pos++;
    }

    // If value not found
    if (temp == NULL)
        return;

    // deleting 1st node
    if (pos == 1)
    {
        Node *temp = head;

        // update head
        head = head->next;
        head->prev = NULL;

        // now free memory
        temp->next = NULL;
        delete temp;
    }
    // deleting any middle or last node
    else
    {
        Node *current = head;  // in start it will point to 1st node
        Node *previous = NULL; // in start as there is no node before 1st node so it will point to NULL

        int count = 1;

        while (count < pos)
        {
            previous = current;
            current = current->next;

            count++;
        }

        if (current->next == NULL)
        {
            tail = previous;
            previous->next = NULL;
        }
        else
        {
            previous->next = current->next;
            current->next->prev = previous;
        }

        current->next = NULL;
        current->prev = NULL;
        delete current;
    }
}

void deleteNodeWithValuesKthOccurrence(Node *&head, Node *&tail, int value, int occur)
{
    // List is Empty
    if (head == NULL)
        return;

    // int pos = 1;
    int count = 0;
    Node *previous = NULL;
    Node *current = head;

    // while (temp != NULL && temp->data != value)
    while (current != NULL)
    {
        if (current->data == value)
        {
            count++;
        }
        if (count == occur)
        {
            break;
        }

        previous = current;
        current = current->next;
    }

    if (current->next == NULL)
    {
        tail = previous;
    }

    previous->next = current->next;
    current->next->prev = previous;

    current->next = NULL;
    current->prev = NULL;
    delete current;

    // If value not found
    if (current == NULL)
        return;
}

int main()
{
    // Node *node1 = new Node(10);
    // Node *head = node1;
    // Node *tail = node1;

    Node *head = new Node(3);
    Node *tail = head;

    cout << "\nHead already created:" << endl;

    print(head);

    cout << "\nInsert at head:" << endl;

    insertAtHead(head, 3);
    print(head);
    insertAtHead(head, 2);
    print(head);

    cout << "\nInsert at tail:" << endl;

    insertAtTail(tail, 5);
    print(head);
    insertAtTail(tail, 12);
    print(head);

    cout << "\nInsert at position:" << endl;

    insertAtPosition(head, tail, 1, 20);
    print(head);
    insertAtPosition(head, tail, 4, 40);
    print(head);
    insertAtPosition(head, tail, 8, 3);
    print(head);

    // cout << "\nDelete 1st pos:" << endl;

    // deleteNodeWithPos(head, tail, 1);
    // print(head);
    // deleteNodeWithPos(head, tail, 3);
    // print(head);
    // deleteNodeWithPos(head, tail, 6);
    // print(head);

    // cout << "\nDelete 1st occurrence of value:" << endl;

    // deleteNodeWithValue(head, tail, 12);
    // print(head);

    cout << "\nDelete kth occurrence of value:" << endl;

    deleteNodeWithValuesKthOccurrence(head, tail, 3, 2);
    print(head);

    // cout << "\nDelete all occurrences of value:" << endl;

    // deleteAllNodesWithValue(head, tail, 3);
    // print(head);

    cout << endl;
    cout << "Head: " << head->data << endl;
    cout << "Tail: " << tail->data << endl;
}