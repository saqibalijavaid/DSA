#include <iostream>
using namespace std;

class Stack
{
    int *arr;
    int cap;
    int top;

public:
    Stack(int capacity)
    {
        this->cap = capacity;
        this->top = -1;
        arr = new int[cap];
    }
    ~Stack()
    {
        delete[] arr;
    }

    void push(int data)
    {
        if (isFull())
        {
            cout << "Stack Overflowed" << endl;
            return;
        }
        arr[++top] = data;
    }

    void pop()
    {
        if (top == -1)
        {
            cout << "Stack Underflowed" << endl;
        }
        else
        {
            top--;
        }
    }

    int peek()
    {
        if (top == -1)
            throw runtime_error("Stack Underflowed");
        else
            return arr[top];
    }

    bool isEmpty()
    {
        if (top == -1)
            return true;
        else
            return false;
    }

    bool isFull()
    {
        if (top == cap - 1)
            return true;
        else
            return false;
    }

    int size()
    {
        return top + 1;
    }

    void print()
    {
        cout << "Stack Elements:" << endl;
        for (int i = 0; i <= top; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main()
{
    int cap;
    cout << "Enter the capacity of Stack: ";
    cin >> cap;
    Stack s(cap);
    int choice, value;

    cout << endl;
    cout << "--- Stack Implementation Using Array ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Push Element" << endl;
        cout << " 2. pop Element" << endl;
        cout << " 3. Get Top Element" << endl;
        cout << " 4. Check if Stack is Empty" << endl;
        cout << " 5. Check if Stack is Full" << endl;
        cout << " 6. Size of Stack" << endl;
        cout << " 7. Print Stack" << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value to push: ";
            cin >> value;
            s.push(value);
            break;

        case 2:
            s.pop();
            break;

        case 3:
            try
            {
                cout << "Top element: " << s.peek() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 4:
            if (s.isEmpty())
                cout << "Stack is empty." << endl;
            else
                cout << "Stack is not empty." << endl;
            break;
        case 5:
            if (s.isFull())
                cout << "Stack is full." << endl;
            else
                cout << "Stack is not full." << endl;
            break;

        case 6:
            cout << "Size of stack: " << s.size() << endl;
            break;

        case 7:
            s.print();
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}