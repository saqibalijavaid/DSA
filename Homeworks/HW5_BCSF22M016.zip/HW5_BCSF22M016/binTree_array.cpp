#include <iostream>

using namespace std;

class BinaryTree
{
private:
    int *tree;
    int cap;
    int currentSize;

public:
    BinaryTree(int capacity)
    {
        this->cap = capacity;
        tree = new int[cap];
        currentSize = 0;
    }

    ~BinaryTree()
    {
        delete[] tree;
    }

    void insert(int element)
    {
        if (currentSize < cap)
        {
            tree[currentSize] = element;
            currentSize++;
        }
        else
        {
            cout << "Tree is full. Cannot insert element." << endl;
        }
    }

    void deleteElement(int element)
    {
        int index = find(element);

        if (index == -1)
        {
            cout << "Element not found in the tree." << endl;
            return;
        }

        tree[index] = tree[currentSize - 1];
        currentSize--;

        cout << "Element deleted." << endl;
    }

    int find(int element)
    {
        for (int i = 0; i < currentSize; i++)
        {
            if (tree[i] == element)
            {
                return i;
            }
        }
        return -1; // Element not found
    }

    int getLeftChild(int index)
    {
        int left = 2 * index + 1;
        if (left >= currentSize)
        {
            return -1;
        }
        return tree[left];
    }

    int getRightChild(int index)
    {
        int right = 2 * index + 2;
        if (right >= currentSize)
        {
            return -1;
        }
        return tree[right];
    }

    int getParent(int index)
    {
        if (index <= 0)
        {
            return -1;
        }
        return tree[(index - 1) / 2];
    }

    void traverseInOrder(int index)
    {
        if (index >= currentSize)
            return;
        traverseInOrder(2 * index + 1);
        cout << tree[index] << " ";
        traverseInOrder(2 * index + 2);
    }

    void traversePreOrder(int index)
    {
        if (index >= currentSize)
            return;
        cout << tree[index] << " ";
        traversePreOrder(2 * index + 1);
        traversePreOrder(2 * index + 2);
    }

    void traversePostOrder(int index)
    {
        if (index >= currentSize)
            return;
        traversePostOrder(2 * index + 1);
        traversePostOrder(2 * index + 2);
        cout << tree[index] << " ";
    }

    void levelOrderTraversal()
    {
        for (int i = 0; i < currentSize; i++)
        {
            cout << tree[i] << " ";
        }
        cout << endl;
    }

    bool isEmpty()
    {
        return currentSize == 0;
    }

    int size()
    {
        return currentSize;
    }
};

int main()
{
    BinaryTree bt(10);
    int choice, element, index;

    cout << endl;
    cout << "--- Binary Tree Using Array ---" << endl;

    do
    {
        cout << endl;
        cout << "1. Insert" << endl;
        cout << "2. Delete" << endl;
        cout << "3. Find" << endl;
        cout << "4. Get Right Child" << endl;
        cout << "5. Get Left Child" << endl;
        cout << "6. Get Parent" << endl;
        cout << "7. In-Order Traversal" << endl;
        cout << "8. Pre-Order Traversal" << endl;
        cout << "9. Post-Order Traversal" << endl;
        cout << "10. Level Order Traversal" << endl;
        cout << "11. Is Empty" << endl;
        cout << "12. Size" << endl;
        cout << "13. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter element to insert: ";
            cin >> element;
            bt.insert(element);
            break;
        case 2:
            cout << "Enter element to delete: ";
            cin >> element;
            bt.deleteElement(element);
            break;
        case 3:
            cout << "Enter element to find: ";
            cin >> element;
            index = bt.find(element);
            if (index != -1)
            {
                cout << "Element found at index: " << index << endl;
            }
            else
            {
                cout << "Element not found." << endl;
            }
            break;
        case 4:
            cout << "Enter index to find right child: ";
            cin >> index;
            cout << "Right child: " << bt.getRightChild(index) << endl;
            break;
        case 5:
            cout << "Enter index to find left child: ";
            cin >> index;
            cout << "Left child: " << bt.getLeftChild(index) << endl;
            break;
        case 6:
            cout << "Enter index to find parent: ";
            cin >> index;
            cout << "Parent: " << bt.getParent(index) << endl;
            break;
        case 7:
            bt.traverseInOrder(0);
            cout << endl;
            break;
        case 8:
            bt.traversePreOrder(0);
            cout << endl;
            break;
        case 9:
            bt.traversePostOrder(0);
            cout << endl;
            break;
        case 10:
            bt.levelOrderTraversal();
            break;
        case 11:
            cout << (bt.isEmpty() ? "Tree is empty." : "Tree is not empty.") << endl;
            break;
        case 12:
            cout << "Size of the tree: " << bt.size() << endl;
            break;
        case 13:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 13);

    return 0;
}