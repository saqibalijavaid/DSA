#include <iostream>
using namespace std;

class CircularQueue
{
    int *arr;
    int cap;
    int frontPtr;
    int rearPtr;

public:
    CircularQueue(int capacity)
    {
        this->cap = capacity;
        this->frontPtr = this->rearPtr = -1;
        arr = new int[cap];
    }
    ~CircularQueue()
    {
        delete[] arr;
    }

    void enqueue(int data) // Add an item to the end of the queue.
    {
        if (isFull())
        {
            cout << "Queue Overflowed!" << endl;
            return;
        }

        if (frontPtr == -1) // first element to push
        {
            frontPtr = rearPtr = 0;
            arr[rearPtr] = data;
        }
        else if (rearPtr == cap - 1 && frontPtr != 0) // following circular path
        {
            rearPtr = 0;
            arr[rearPtr] = data;
        }
        else // following linear path
        {
            arr[++rearPtr] = data;
        }
    }

    int dequeue()
    {
        if (isEmpty())
        {
            throw runtime_error("Queue Underflowed!");
        }

        int data = arr[frontPtr];

        if (frontPtr == rearPtr) // Single element
        {
            frontPtr = rearPtr = -1;
        }
        else if (frontPtr == cap - 1) // following circular path
        {
            frontPtr = 0;
        }
        else // following linear path
        {
            frontPtr++;
        }

        return data;
    }

    int front()
    {
        if (isEmpty())
        {
            throw runtime_error("Empty Queue!");
        }

        return arr[frontPtr];
    }

    int rear()
    {
        if (isEmpty())
        {
            throw runtime_error("Empty Queue!");
        }

        return arr[rearPtr];
    }

    bool isEmpty()
    {
        if ((frontPtr == -1 && rearPtr == -1))
            return true;
        else
            return false;
    }

    bool isFull()
    {
        if ((frontPtr == 0 && rearPtr == cap - 1) || (rearPtr == (frontPtr - 1) % (cap - 1)))
            return true;
        else
            return false;
    }

    int size()
    {
        if (isEmpty())
            return 0;

        if (rearPtr >= frontPtr)
            return rearPtr - frontPtr + 1;
        else
            return (cap - frontPtr) + (rearPtr + 1);
    }

    void print()
    {
        if (isEmpty())
        {
            cout << "Queue is Empty." << endl;
            return;
        }

        cout << "Queue Elements:" << endl;
        if (rearPtr >= frontPtr)
        {
            for (int i = frontPtr; i <= rearPtr; i++)
            {
                cout << arr[i] << " ";
            }
        }
        else
        {
            for (int i = frontPtr; i < cap; i++)
                cout << arr[i] << " ";
            for (int i = 0; i <= rearPtr; i++)
                cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main()
{
    int cap;
    cout << "Enter the capacity of Queue: ";
    cin >> cap;
    CircularQueue q(cap);
    int choice, value;

    cout << endl;
    cout << "--- Circular Queue Implementation Using Array ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Enqueue Element" << endl;
        cout << " 2. Dequeue Element" << endl;
        cout << " 3. Get Front Element" << endl;
        cout << " 4. Get Rear Element" << endl;
        cout << " 5. Check if Queue is Empty" << endl;
        cout << " 6. Check if Queue is Full" << endl;
        cout << " 7. Size of Queue" << endl;
        cout << " 8. Print Queue" << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {

        case 1:
            cout << "Enter value to enqueue: ";
            cin >> value;
            q.enqueue(value);
            break;

        case 2:
            try
            {
                cout << "Dequeue element: " << q.dequeue() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 3:
            try
            {
                cout << "Front Element: " << q.front() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 4:
            try
            {
                cout << "Rear Element: " << q.rear() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 5:
            if (q.isEmpty())
                cout << "Queue is empty." << endl;
            else
                cout << "Queue is not empty." << endl;
            break;

        case 6:
            if (q.isFull())
                cout << "Queue is full." << endl;
            else
                cout << "Queue is not full." << endl;
            break;

        case 7:
            cout << "Size of Queue: " << q.size() << endl;
            break;

        case 8:
            q.print();
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}