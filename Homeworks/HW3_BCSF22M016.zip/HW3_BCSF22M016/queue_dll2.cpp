#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // Constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};

class Queue
{
    Node *head;
    Node *tail;

public:
    // Constructor
    Queue() : head(NULL), tail(NULL) {}

    // Destructor
    // All dynamically allocated nodes in the LL will be properly deleted when the Queue object is destroyed
    ~Queue()
    {
        while (head != NULL)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }

    void enqueue(int data) // Add an item to the end of the queue.
    {
        if (tail == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
        }
        else
        {
            Node *temp = new Node(data);
            tail->next = temp;
            temp->prev = tail;
            tail = temp;
        }
    }

    int dequeue() // Remove and return the item from the front of the queue.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }
        else
        {
            Node *temp = head;

            if (head->next == NULL) // if there is only one node
            {
                head = NULL;
                tail = NULL;
            }

            else
            {
                head = head->next;
                head->prev = NULL;
            }

            int toReturn = temp->data;
            temp->next = NULL;
            delete temp;
            return toReturn;
        }
    }

    void addFront(int data) // Add an item to the front of the queue.
    {
        if (head == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
        }
        else
        {
            Node *temp = new Node(data);
            temp->next = head;
            head->prev = temp;
            head = temp;
        }
    }

    int removeRear() // Remove and return the item from the rear of the queue.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }
        else
        {
            Node *temp = tail;
            tail=tail->prev;

            if (tail == NULL) // if there is only one node
            {
                head = NULL;
            }

            else
            {
                tail->next = NULL;
            }

            int toReturn = temp->data;
            temp->next = NULL;
            temp->prev = NULL;
            delete temp;
            return toReturn;
        }
    }

    int peekFront() // Return the item at the front of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return head->data;
    }
    int peekRear() // Return the item at the rear of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return tail->data;
    }
    bool isEmpty() // Check if the queue is empty.
    {
        return head == NULL && tail == NULL;
    }

    int size() // Return the number of items in the queue.
    {
        int count = 0;
        Node *temp = head;

        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        return count;
    }

    void print() // Prints the items in the queue.
    {
        Node *temp = head;

        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    Queue q;
    int choice, value;

    cout << endl;
    cout << "--- Queue Implementation Using DLL2 ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Enqueue Element" << endl;
        cout << " 2. Dequeue Element" << endl;
        cout << " 3. Add Element to Front" << endl;
        cout << " 4. Remove Rear Element" << endl;
        cout << " 5. Get Peek Front of Queue" << endl;
        cout << " 6. Get Peek Rear of Queue" << endl;
        cout << " 7. Check if Queue is Empty" << endl;
        cout << " 8. Get Queue Size" << endl;
        cout << " 9. Print Queue" << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value to enqueue: ";
            cin >> value;
            q.enqueue(value);
            break;

        case 2:
            cout << "Dequeue element: " << q.dequeue() << endl;
            break;

        case 3:
            cout << "Enter value to add to front: ";
            cin >> value;
            q.addFront(value);
            break;

        case 4:
            cout << "Element removed from rear: " << q.removeRear() << endl;
            break;

        case 5:
            try
            {
                cout << "Front Peek: " << q.peekFront() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 6:
            try
            {
                cout << "Rear Peek: " << q.peekRear() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 7:
            if (q.isEmpty())
                cout << "Queue is empty." << endl;
            else
                cout << "Queue is not empty." << endl;
            break;

        case 8:
            cout << "Size of queue: " << q.size() << endl;
            break;

        case 9:
            q.print();
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}