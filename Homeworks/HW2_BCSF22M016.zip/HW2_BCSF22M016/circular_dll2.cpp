#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node *prev;

    // constructor
    Node(int d) : data(d), next(NULL), prev(NULL) {}

    // destructor
    ~Node()
    {
        // int toDelete = this->data;

        if (this->next != NULL)
        {
            this->next = NULL;
            delete this;
        }

        // cout << "Value to be deleted: " << toDelete << endl;
    }

    friend class CDLL;
};

class CDLL
{
public:
    Node *head;
    Node *tail;

    // constructor
    CDLL()
    {
        this->head = NULL;
        this->tail = NULL;
    }

    void insertAtHead(int data)
    {
        if (head == NULL)
        {
            Node *temp = new Node(data);

            head = temp;
            tail = temp;

            temp->next = temp;
            temp->prev = temp;
        }
        else
        {
            Node *temp = new Node(data);

            head->prev->next = temp;
            temp->prev = head->prev;
            head->prev = temp;
            temp->next = head;

            head = temp;
        }
    }
    void insertAtTail(int data)
    {
        if (tail == NULL)
        {
            Node *temp = new Node(data);

            head = temp;
            tail = temp;

            temp->next = temp;
            temp->prev = temp;
        }
        else
        {
            Node *temp = new Node(data);

            tail->next->prev = temp;
            temp->next = tail->next;
            temp->prev = tail;
            tail->next = temp;

            tail = temp;
        }
    }

    void insertBefore(int searchValue, int data)
    {
        if (head == nullptr)
        {
            cout << "List is empty." << endl;
            return;
        }

        Node *current = head;

        do
        {
            if (current->data == searchValue)
            {
                Node *temp = new Node(data);

                temp->next = current;
                temp->prev = current->prev;
                current->prev->next = temp;
                current->prev = temp;

                if (current == head)
                {
                    head = temp;
                }

                cout << "Inserted: " << data << " - Before: " << searchValue << endl;

                return;
            }

            current = current->next;

        } while (current != head);
    }

    void insertAfter(int searchValue, int data)
    {
        if (head == nullptr)
        {
            cout << "List is empty." << endl;
            return;
        }

        Node *current = head;

        do
        {
            if (current->data == searchValue)
            {
                Node *temp = new Node(data);

                temp->next = current->next;
                temp->prev = current;
                current->next->prev = temp;
                current->next = temp;

                if (current == tail)
                {
                    tail = temp;
                }

                cout << "Inserted: " << data << " - After: " << searchValue << endl;

                return;
            }

            current = current->next;

        } while (current != head);
    }

    void deleteFirstOccurrence(int searchValue)
    { // empty list
        if (head == NULL)
        {
            cout << "Empty List, statement from deleteNode func!" << endl;
            return;
        }
        else
        {
            Node *temp = head;

            while (temp->data != searchValue)
            {
                temp = temp->next;
            }

            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;

            // if there is only one node and we are deleting it we need to take care of head
            if (temp == temp->next)
            {
                head = NULL;
            }

            // if we are deleting the node which is head, in that case we need to update head before deleting current
            if (temp == head)
            {
                head = temp->next;
            }

            temp->next = NULL;
            temp->prev = NULL;

            delete temp;
        }
    }

    void deleteKthOccurrence(int searchValue, int occurence)
    { // empty list
        if (head == NULL)
        {
            cout << "Empty List, statement from deleteNode func!" << endl;
            return;
        }
        else
        {
            int count = 0;
            Node *current = head;

            do
            {
                if (current->data == searchValue)
                {
                    count++;
                }
                if (count == occurence)
                {
                    break;
                }

                current = current->next;

            } while (current != head);

            current->prev->next = current->next;
            current->next->prev = current->prev;

            // if there is only one node and we are deleting it we need to take care of head
            if (current == current->next)
            {
                head = NULL;
                tail = NULL;
            }

            // if we are deleting the node which is head, in that case we need to update head before deleting current
            if (current == head)
            {
                head = current->next;
            }

            // if we are deleting the node which is tail, in that case we need to update tail before deleting current
            if (current == tail)
            {
                tail = current->prev;
            }

            current->next = NULL;
            current->prev = NULL;

            delete current;
        }
    }

    void deleteAllOccurrence(int searchValue, int occurence)
    { // empty list
        if (head == NULL)
        {
            cout << "Empty List, statement from deleteNode func!" << endl;
            return;
        }
        else
        {
            Node *current = head;

            do
            {
                if (current->data == searchValue)
                {
                    current->prev->next = current->next;
                    current->next->prev = current->prev;

                    // if there is only one node and we are deleting it we need to take care of head
                    if (current == current->next)
                    {
                        head = NULL;
                        tail = NULL;
                    }

                    // if we are deleting the node which is head, in that case we need to update head before deleting current
                    if (current == head)
                    {
                        head = current->next;
                    }

                    // if we are deleting the node which is tail, in that case we need to update tail before deleting current
                    if (current == tail)
                    {
                        tail = current->prev;
                    }

                    Node *temp = current;
                    current = current->next;

                    temp->next = NULL;
                    temp->prev = NULL;

                    delete temp;
                }
                else
                {
                    current = current->next;
                }

            } while (current != head);
        }
    }

    void insertInAscendingOrder(int value)
    {
        Node *newNode = new Node(value);

        if (head == nullptr)
        {
            // List is empty, so newNode is the only node
            head = newNode;
            tail = newNode;

            head->next = head;
            head->prev = head;
        }
        else if (value <= head->data)
        {
            // Insert before the head
            newNode->next = head;
            newNode->prev = tail;
            head->prev = newNode;
            tail->next = newNode;

            head = newNode;
        }
        else if (value >= tail->data)
        {
            // Insert after the tail
            newNode->next = head;
            newNode->prev = tail;
            tail->next = newNode;
            head->prev = newNode;

            tail = newNode;
        }
        else
        {
            // Insert in the middle
            Node *current = head;

            while (current->next != head && current->next->data < value)
            {
                current = current->next;
            }

            newNode->next = current->next;
            newNode->prev = current;
            current->next->prev = newNode;
            current->next = newNode;
        }
    }

    void insertInDescendingOrder(int value)
    {
        Node *newNode = new Node(value);

        if (head == nullptr)
        {
            // List is empty, so newNode is the only node
            head = newNode;
            tail = newNode;
            head->next = head;
            head->prev = head;
        }
        else if (value >= head->data)
        {
            // Insert before the head (since we want descending order)
            newNode->next = head;
            newNode->prev = tail;
            head->prev = newNode;
            tail->next = newNode;

            head = newNode;
        }
        else if (value <= tail->data)
        {
            // Insert after the tail (since we want descending order)
            newNode->next = head;
            newNode->prev = tail;
            tail->next = newNode;
            head->prev = newNode;

            tail = newNode;
        }
        else
        {
            // Insert in the middle
            Node *current = head;

            while (current->next != head && current->next->data > value)
            {
                current = current->next;
            }

            newNode->next = current->next;
            newNode->prev = current;
            current->next->prev = newNode;
            current->next = newNode;
        }
    }
};

void print(Node *head)
{
    // empty list
    if (head == NULL)
    {
        cout << "Empty List, statement from print func!" << endl;
    }
    else
    {
        Node *temp = head;
        do
        {
            cout << head->data << " ";
            head = head->next;

        } while (head != temp);
        cout << endl;
    }
}

void printReverse(Node *tail)
{
    // empty list
    if (tail == NULL)
    {
        cout << "Empty List, statement from print func!" << endl;
    }
    else
    {
        Node *temp = tail;
        do
        {
            cout << tail->data << " ";
            tail = tail->prev;

        } while (tail != temp);
        cout << endl;
    }
}

int main()
{
    CDLL list;
    int choice, value, searchValue, occurrence;

    cout << endl;
    cout << "--- Circular Doubly Linked List Implementation ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Insert at Head" << endl;
        cout << " 2. Insert at Tail" << endl;
        cout << " 3. Insert Before a Value" << endl;
        cout << " 4. Insert After a Value" << endl;
        cout << " 5. Delete First Occurrence of a Value" << endl;
        cout << " 6. Delete Kth Occurrence of a Value" << endl;
        cout << " 7. Delete All Occurrences of a Value" << endl;
        cout << " 8. Insert in Ascending Order" << endl;
        cout << " 9. Insert in Descending Order" << endl;
        cout << "10. Print List (Forward)" << endl;
        cout << "11. Print List (Reverse)" << endl;
        cout << " 0. Exit" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value to insert at head: ";
            cin >> value;
            list.insertAtHead(value);
            break;

        case 2:
            cout << "Enter value to insert at tail: ";
            cin >> value;
            list.insertAtTail(value);
            break;

        case 3:
            cout << "Enter value to insert: ";
            cin >> value;
            cout << "Enter value before which to insert: ";
            cin >> searchValue;
            list.insertBefore(searchValue, value);
            break;

        case 4:
            cout << "Enter value to insert: ";
            cin >> value;
            cout << "Enter value after which to insert: ";
            cin >> searchValue;
            list.insertAfter(searchValue, value);
            break;

        case 5:
            cout << "Enter value to delete (first occurrence): ";
            cin >> searchValue;
            list.deleteFirstOccurrence(searchValue);
            break;

        case 6:
            cout << "Enter value to delete: ";
            cin >> searchValue;
            cout << "Enter occurrence of value to delete: ";
            cin >> occurrence;
            list.deleteKthOccurrence(searchValue, occurrence);
            break;

        case 7:
            cout << "Enter value to delete: ";
            cin >> searchValue;
            cout << "Deleting all occurrences of " << searchValue << endl;
            list.deleteAllOccurrence(searchValue, 0);
            break;

        case 8:
            cout << "Enter value to insert in ascending order: ";
            cin >> value;
            list.insertInAscendingOrder(value);
            break;

        case 9:
            cout << "Enter value to insert in descending order: ";
            cin >> value;
            list.insertInDescendingOrder(value);
            break;

        case 10:
            cout << "Printing List (Forward): ";
            print(list.head);
            break;

        case 11:
            cout << "Printing List (Reverse): ";
            printReverse(list.tail);
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}