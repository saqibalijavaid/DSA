#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    // constructor
    Node(int data)
    {
        this->data = data;
        this->next = NULL;
    }

    // destructor
    ~Node()
    {
        // int toDelete = this->data;

        if (this->next != NULL)
        {
            this->next = NULL;
            delete this;
        }

        // cout << "Value to be deleted: " << toDelete << endl;
    }
};

class Stack
{
    Node *top;

public:
    Node *head;
    Node *tail;

    // public:
    // constructor
    Stack()
    {
        this->top = NULL;
        this->head = NULL;
        this->tail = NULL;
    }

    void push(int data)
    {
        if (head == NULL)
        {
            Node *temp = new Node(data);
            head = temp;
            tail = temp;
            top = tail;
        }
        else
        {
            Node *temp = new Node(data);

            tail->next = temp;
            temp->next = NULL;
            tail = temp;
            top = tail;
        }
    }

    void pull()
    {
        if (top == NULL)
        {
            cout << "Stack Underflowed" << endl;
        }
        else if (head == tail)
        {
            delete head;
            top = NULL;
            head = NULL;
            tail = NULL;
        }
        else
        {
            Node *previous = NULL;
            Node *current = head;

            while (current != tail)
            {
                previous = current;
                current = current->next;
            }

            tail = previous;
            top = tail;

            if (previous != NULL)
            {
                previous->next = NULL;
            }

            delete current;
        }
    }

    int peek()
    {
        if (top != NULL)
            return top->data;
        else
            throw runtime_error("Stack is empty!");
    }

    bool isEmpty()
    {
        if (top == NULL)
            return true;
        else
            return false;
    }
};

int size(Stack &s)
{
    int count = 0;
    Stack tempStack;

    while (!s.isEmpty())
    {
        count++;
        int topData = s.peek();
        s.pull();
        tempStack.push(topData);
    }

    while (!tempStack.isEmpty())
    {
        s.push(tempStack.peek());
        tempStack.pull();
    }

    return count;
}

void print(Stack &s)
{
    Stack tempStack;

    cout << "Top to Bottom: ";
    while (!s.isEmpty())
    {
        int topData = s.peek();

        cout << topData << " ";

        s.pull();
        tempStack.push(topData);
    }

    cout << endl;

    while (!tempStack.isEmpty())
    {
        s.push(tempStack.peek());
        tempStack.pull();
    }
}

int main()
{
    Stack s;
    int choice, value;

    cout << endl;
    cout << "--- Stack Implementation Using SLL2 ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Push Element" << endl;
        cout << " 2. Pull Element" << endl;
        cout << " 3. Get Top Element" << endl;
        cout << " 4. Check if Stack is Empty" << endl;
        cout << " 5. Size of Stack" << endl;
        cout << " 6. Print Stack (Top to Bottom)" << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                cout << "Enter value to push: ";
                cin >> value;
                s.push(value);
                break;

            case 2:
                s.pull();
                break;

            case 3:
                try
                {
                    cout << "Top element: " << s.peek() << endl;
                }
                catch (const runtime_error &e)
                {
                    cout << e.what() << endl;
                }
                break;

            case 4:
                if (s.isEmpty())
                    cout << "Stack is empty." << endl;
                else
                    cout << "Stack is not empty." << endl;
                break;

            case 5:
                cout << "Size of stack: " << size(s) << endl;
                break;

            case 6:
                print(s);
                break;

            case 0:
                cout << "Exiting..." << endl;
                break;

            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}
