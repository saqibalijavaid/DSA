#include <iostream>
using namespace std;

// function to perform insertion sort
void insertionSort(int *arr, int n)
{
    for (int i = 1; i < n; i++)
    {
        int currEle = arr[i];
        int prevInd = i - 1;

        while (prevInd >= 0 && arr[prevInd] > currEle)
        {
            arr[prevInd + 1] = arr[prevInd];
            prevInd--;
        }

        arr[prevInd + 1] = currEle;
    }
}

int *sortedInsert(int *arr, int n, int value)
{
    insertionSort(arr, n);

    // New array with one extra space for new value
    int *result = new int[n + 1];
    bool inserted = false;

    for (int i = 0, j = 0; i < n; i++, j++)
    {
        if (!inserted && arr[i] >= value)
        {
            result[j++] = value;
            inserted = true;
        }
        result[j] = arr[i];
    }

    if (!inserted)
    {
        result[n] = value;
    }

    return result;
}

int main()
{
    int *arr;
    int n, value;

    while (true)
    {
        cout << endl;
        cout << "How many elements you want to add in array (-1 to exit): ";
        cin >> n;

        if (n == -1)
            break;

        arr = new int[n];

        cout << "Enter elements of the array:" << endl;
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
        }

        cout << "Enter value to be inserted: ";
        cin >> value;

        cout << "Array Before insertion: ";
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;

        int *result = sortedInsert(arr, n, value);

        cout << "Array after insertion: ";
        for (int i = 0; i <= n; i++)
        {
            cout << result[i] << " ";
        }
        cout << endl;

        // free dynamically allocated memory
        delete[] arr;
        delete[] result;
    }

    return 0;
}