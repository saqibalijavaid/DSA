#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    int priority;
    Node *next;
    Node *prev;

    // Constructor
    Node(int data, int priority)
    {
        this->data = data;
        this->priority = priority;
        this->next = NULL;
        this->prev = NULL;
    }
};

class Queue
{
    Node *head;
    Node *tail;

public:
    // Constructor
    Queue() : head(NULL), tail(NULL) {}

    // Destructor
    // All dynamically allocated nodes in the LL will be properly deleted when the Queue object is destroyed
    ~Queue()
    {
        while (head != NULL)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }

    void enqueue(int data, int priority) // Add an item to the end of the queue.
    {
        Node *temp = new Node(data, priority);

        // if the queue is empty
        if (head == NULL)
        {
            head = tail = temp;
        }

        // if the new node has higher priority than the head
        else if (head->priority < priority)
        {
            temp->next = head;
            head->prev = temp;

            head = temp;

            if (tail == NULL)
            {
                tail = head;
            }
        }
        else
        {
            Node *current = head;
            while (current->next != NULL && current->next->priority >= priority)
            {
                current = current->next;
            }

            temp->next = current->next;
            temp->prev = current;
            if (current->next != NULL)
            {
                current->next->prev = temp;
            }
            current->next = temp;

            if (current == tail)
            {
                tail = temp;
            }
        }
    }

    int dequeue() // Remove and return the item from the front of the queue.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }
        else
        {
            Node *temp = head;

            if (head->next == NULL) // if there is only one node
            {
                head = NULL;
                tail = NULL;
            }

            else
            {
                head = head->next;
                head->prev = NULL;
            }

            int toReturn = temp->data;
            temp->next = NULL;
            delete temp;
            return toReturn;
        }
    }

    int peekFront() // Return the item at the front of the queue without removing it.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty List!");
        }

        return head->data;
    }

    bool isEmpty() // Check if the queue is empty.
    {
        return head == NULL && tail == NULL;
    }

    int size() // Return the number of items in the queue.
    {
        int count = 0;
        Node *temp = head;

        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        return count;
    }

    void print() // Prints the items in the queue.
    {
        Node *temp = head;

        cout << " Priority   Value" << endl;
        while (temp != NULL)
        {
            cout << " " << temp->priority << "         " << temp->data << endl;
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    Queue q;
    int choice, value, priority;

    cout << endl;
    cout << "--- Priority Queue Implementation Using DLL2 ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Enqueue Element" << endl;
        cout << " 2. Dequeue Element" << endl;
        cout << " 3. Get Peek Front of Queue" << endl;
        cout << " 4. Get Queue Size" << endl;
        cout << " 5. Print Queue" << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value to enqueue: ";
            cin >> value;
            cout << "Enter value's priority: ";
            cin >> priority;
            q.enqueue(value, priority);
            break;

        case 2:

            try
            {
                cout << "Dequeue element: " << q.dequeue() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 3:
            try
            {
                cout << "Front Peek: " << q.peekFront() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 4:
            cout << "Size of queue: " << q.size() << endl;
            break;

        case 5:
            q.print();
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}