#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    // constructor
    Node(int data)
    {
        this->data = data;
        this->next = this;
    }
};

class CirQueueSLL2
{
public:
    Node *head;
    Node *tail;

    // constructor
    CirQueueSLL2()
    {
        this->head = NULL;
        this->tail = NULL;
    }

    // destructor
    ~CirQueueSLL2()
    {
        if (head != NULL)
        {
            Node *current = head;
            Node *nextNode;

            do
            {
                nextNode = current->next;

                current->next = NULL;
                delete current;
                current = nextNode;
            } while (current != head);
        }
    }

    void enqueue(int data) // Add an item to the end of the queue.
    {
        Node *temp = new Node(data);

        if (head == NULL)
        {
            head = tail = temp;
        }
        else
        {
            temp->next = tail->next;
            tail->next = temp;

            tail = temp;
        }
    }

    int dequeue()
    {
        if (isEmpty())
        {
            throw runtime_error("Empty Queue!");
        }

        Node *temp = head;
        int toDelete = head->data;

        if (head == tail) // if there is only one node
        {
            // head->next = NULL;
            // delete head;
            head = tail = NULL;
        }
        else
        {
            head = head->next;

            tail->next = head;
        }

        temp->next = NULL;
        delete temp;

        return toDelete;
    }

    int peekFront()
    {
        if (isEmpty())
        {
            throw runtime_error("Empty Queue!");
        }

        return head->data;
    }

    bool isEmpty()
    {
        return head == NULL && tail == NULL;
    }

    int size() // Return the number of items in the queue.
    {
        if (isEmpty())
        {
            throw runtime_error("Empty Queue!");
        }

        Node *temp = head;
        int count = 0;

        do
        {
            count++;
            temp = temp->next;
        } while (temp != head);

        return count;
    }

    void print() // Prints the items in the queue.
    {
        if (isEmpty())
        {
            cout << "Empty Queue!" << endl;
            return;
        }

        Node *temp = head;

        do
        {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);

        cout << endl;
    }
};

int main()
{
    CirQueueSLL2 q;
    int choice, value;

    cout << endl;
    cout << "--- Circular Queue Implementation Using SLL2 ---" << endl;

    do
    {
        cout << endl;
        cout << " 1. Add an item to the end of the queue." << endl;
        cout << " 2. Remove and return the item from the front of the queue." << endl;
        cout << " 3. Return the item at the front of the queue without removing it." << endl;
        cout << " 4. Return the number of items in the queue." << endl;
        cout << " 5. Prints the items in the queue." << endl;
        cout << " 0. To Exit!" << endl;
        cout << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {

        case 1:
            cout << "Enter value to Push Back: ";
            cin >> value;
            q.enqueue(value);
            break;

        case 2:
            try
            {
                cout << "Pop Front element: " << q.dequeue() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 3:
            try
            {
                cout << "Front Peek: " << q.peekFront() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 4:
            try
            {
                cout << "Size of queue: " << q.size() << endl;
            }
            catch (const runtime_error &e)
            {
                cout << e.what() << endl;
            }
            break;

        case 5:
            q.print();
            break;

        case 0:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}